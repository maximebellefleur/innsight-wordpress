//var WpJsonUrl = document.querySelector('link[rel="https://api.w.org/"]').href;
//var siteUrl = WpJsonUrl.replace('/wp-json/', '').split('index.php?')[0];
var siteUrl = self.location.origin;
//var windowUrl = window.location.origin;
//console.log('siteUrl: ' + siteUrl+ ' windowUrl: '+windowUrl);

self.addEventListener('install', function(e) {
    e.waitUntil(
        caches.open('map-store').then(function(cache) {
            const urlsToCache = [
                siteUrl+'/balmers-interactive-map-of-interlaken-switzerland/',
                siteUrl+'/wp-content/plugins/yuna-innsight/css/yuna-innsight.css',
                siteUrl+'/wp-content/plugins/yuna-innsight/js/yuna-innsight-settings.js',
                siteUrl+'/wp-content/plugins/yuna-innsight/img/icon-512.png'
            ];
            console.log('Attempting to cache:', urlsToCache);
            const cachePromises = urlsToCache.map(url =>
                fetch(url, { mode: 'no-cors' })
                .then(response => {
                    if (!response.ok && response.type !== 'opaque') {
                        throw new TypeError('Network response was not ok.');
                    }
                    cache.put(url, response);
                })
            );
            return Promise.all(cachePromises).catch(function(error) {
                console.error('Failed to cache:', error);
                throw error;
            });
        })
    );
});


self.addEventListener('fetch', function(e) {
  e.respondWith(
    caches.match(e.request).then(function(response) {
      return response || fetch(e.request);
    })
  );
});