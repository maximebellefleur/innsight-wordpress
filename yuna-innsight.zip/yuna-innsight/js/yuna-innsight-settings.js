(function ($) {
    var file_frame;
    var mapClicked = false;
    var currentlang = $('html').attr('lang');

    $(document).ready(function($) {
        $('.yuna-innsight-bg-image-upload').on('click', function(event) {
            event.preventDefault();

            if (file_frame) {
                file_frame.open();
                return;
            }

            file_frame = wp.media.frames.file_frame = wp.media({
                title: 'Select an Image',
                button: {
                    text: 'Use this image'
                },
                multiple: false
            });

            file_frame.on('select', function() {
                var attachment = file_frame.state().get('selection').first().toJSON();
                $('input[name="yuna_innsight_settings[yuna_innsight_bg_image]"]').val(attachment.id);
                $('img').attr('src', attachment.sizes.thumbnail.url);
            });

            file_frame.open();
        });

        if (typeof mapData !== 'undefined') {
            var mapOptions = {
                center: [mapData.lat, mapData.lon],
                zoom: mapData.zoom,
                gestureHandling: $('body').hasClass('page-template-page-map') ? false : true,
                fullscreenControl: true,
                fullscreenControlOptions: { position: 'topleft' },
                keyboard: false,
            };

            if ($('body').hasClass('page-template-page-map')) {
                $('body #map').addClass('mapFullScreen');
            }

            var map = L.map('map', mapOptions);

            var tileMap = L.tileLayer('https://{s}.tile.openstreetmap.org/{z}/{x}/{y}.png', {
                maxZoom: 19,
                attribution: '© OpenStreetMap contributors'
            }).addTo(map);

            var control = L.control.layers(null, null, {
                collapsed: false,
                sortLayers: true,
                hideSingleBase: true,
                position: 'bottomright'
            });

            var groupTypes = {};
            var corner1 = L.latLng(mapData.lat, mapData.lon);
            var corner2 = L.latLng(mapData.lat, mapData.lon);
            var allBounds = L.latLngBounds(corner1, corner2);

            if (mapData.add_markers && typeof mapMarkers !== 'undefined') {
                mapMarkers.forEach(function(marker) {
                    var icon_val = (marker.category && (marker.category.indexOf('md-') !== -1 || marker.category.indexOf('map-') !== -1) ) ? marker.category : 'fa-'+marker.type;
                    var icon = L.divIcon({
                        html: '<icon class="fa '+ icon_val + '"></icon>',
                        iconSize: [20, 20],
                        className: 'mapIcon'
                    });

                    var $htmlContent = $(`<p>${marker.desc}</p>`);
                    var updatedHtmlContent = $htmlContent.html();
                    var popup_btn_title = (marker.btn_text) ? marker.btn_text : 'more info';
                    var popup_btn = (marker.btn_url ) ? '<a href="'+marker.btn_url+'" class="more" target="_blank">'+popup_btn_title+'</a>' : '';
                    var translatedTitle = marker.title;

                    var popupContent = '<div class="popupContent">' +
                                        '<div class="title_holder">' + 
                                            '<h3>' + translatedTitle + '</h3>' +
                                            popup_btn +
                                        '</div>' +
                                        (marker.img ? '<div class="img_holder"><img src="' + marker.img + '" alt="' + translatedTitle + '" /></div>' : '') +
                                        '<p>' + updatedHtmlContent + '</p>' +
                                        '<div class="external_action"><ul>' +
                                            '<li class="google"><a href="https://www.google.com/maps/dir/?api=1&amp;destination='+ marker.lat + ',' + marker.lon +'" target="_blank">GMAPS</a></li>' +
                                            '<li class="ios"><a href="https://maps.apple.com/?daddr='+ marker.lat + ',' + marker.lon +'" target="_blank">iOS</a></li>' +
                                        '</ul></div>'
                                    '</div>';

                    var newMarker = L.marker([marker.lat, marker.lon], {icon: icon}).bindPopup(popupContent);

                    if (!groupTypes[marker.type]) {
                        groupTypes[marker.type] = L.markerClusterGroup({
                            iconCreateFunction: function (cluster) {
                                var markers = cluster.getAllChildMarkers();
                                var html = '<div class="number">' + markers.length + '</div>';
                                return L.divIcon({ html: html, className: 'clusterui md-'+marker.type, iconSize: L.point(32, 32) });
                            },
                        });
                        control.addOverlay(groupTypes[marker.type], marker.type);
                    }
                    newMarker.addTo(groupTypes[marker.type]);

                    allBounds.extend(newMarker.getLatLng());
                });
            }

            control.addTo(map);
            Object.keys(groupTypes).forEach(function(type) {
                if($('body').hasClass('single-portfolio') && type === 'activities'){
                    return;
                }
                groupTypes[type].addTo(map);
            });

            function getVisibleBounds() {
                var bounds = new L.LatLngBounds();
                map.eachLayer(function(layer) {
                    if (layer instanceof L.FeatureGroup && map.hasLayer(layer)) {
                        bounds.extend(layer.getBounds());
                    }
                });
                return bounds;
            }
            map.fitBounds(getVisibleBounds());

            if (mapData.add_paths && typeof mapPaths !== 'undefined') {
                mapPaths.forEach(function(path) {
                    var coordinates = path.coordinates.map(function(coordinate) {
                        return coordinate.split(',').map(Number);
                    });

                    var polyline = L.polyline(coordinates, {color: path.color}).addTo(map);
                    map.fitBounds(polyline.getBounds());
                });
            }

            map.on('enterFullscreen', function () {
                mapClicked = true;
                map.gestureHandling.disable();
                $(document).find('.map_container').addClass('fullscreen');
            });
            map.on('exitFullscreen', function () {
                map.gestureHandling.enable();
                mapClicked = false;
                $(document).find('.map_container').removeClass('fullscreen');
            });
            map.on('overlayadd overlayremove', function () {
                var bounds = new L.LatLngBounds();
                map.eachLayer(function (layer) {
                    if (layer instanceof L.FeatureGroup) {
                        bounds.extend(layer.getBounds());
                    }
                });
                if (bounds.isValid()) {
                    map.fitBounds(bounds);
                }
                $('body.single-portfolio #map').addClass('touched');
            });

            map.on('click', function() {
                // Collapse the control when the map is clicked
                //console.log('collapsing controls');
                $('.leaflet-control-layers').removeClass('leaflet-control-layers-expanded');
            });

            // Custom control to add toggle switch
            var ToggleControl = L.Control.extend({
                options: {
                    position: 'bottomright'
                },
                onAdd: function(map) {
                    var container = L.DomUtil.create('div', 'filter-toggle-container');
                    container.innerHTML = `
                        <label class="switch">
                            <input type="checkbox" id="filterToggle">
                            <span class="slider round"></span>
                        </label>
                        <span>Solo mode</span>
                    `;
                    L.DomEvent.disableClickPropagation(container);
                    return container;
                }
            });

            map.addControl(new ToggleControl());

            function updateFilterMode(selectedLayer = null) {
                var isRadioMode = $('#filterToggle').is(':checked');
                var selectedLayers = [];
            
                if (selectedLayer && isRadioMode) {
                    selectedLayers = [selectedLayer];
                }else {
                    // Get the first checked item efficiently
                    var firstChecked = $('input.leaflet-control-layers-selector:checked').first();
                    if (firstChecked.length > 0) {
                        var filterValue = firstChecked.next('span').text().trim();
                        selectedLayers.push(filterValue);
                    }
                }
                
                if (isRadioMode) {
                    if (selectedLayers.length > 1) {
                        // More than one layer selected, leave only the first one on
                        var firstSelectedLayer = selectedLayers[0];
                        selectedLayers = [firstSelectedLayer];
                    }
            
                    // Remove all layers except the selected ones
                    Object.keys(groupTypes).forEach(function(type) {
                        if (type == selectedLayers) {
                            console.log('addLayer:'+type);
                            map.addLayer(groupTypes[type]);
                        } else {
                            map.removeLayer(groupTypes[type]);
                        }
                    });
                } else {
                    return;
                }
            }
            
            $('#filterToggle').on('change', function() {
                updateFilterMode();
            });
            
            $(document).on('change', 'input.leaflet-control-layers-selector', function() {
                var isRadioMode = $('#filterToggle').is(':checked');
                var selectedLayer = $(this).next('span').text().trim();
            
                updateFilterMode(selectedLayer);
            });
        }

        $('#download-kml').click(function(e) {
            e.preventDefault();

            $.ajax({
                type: 'POST',
                url: innsightajax.ajaxurl,
                data: {
                    action: 'generate_kml',
                    post_id: $(document).find('#download-kml').attr('data-postid')
                },
                success: function(data) {
                    var data_url = 'data:application/vnd.google-earth.kml+xml;base64,' + btoa(data);
                    var link = document.createElement('a');
                    link.href = data_url;
                    link.download = 'map.kml';
                    link.click();
                }
            });
        });
    });

    $(window).on('load', function (e) {
        setTimeout(function(){
            $('.app-loading').removeClass('app-loading');
        }, 500);
    });

})(jQuery);
