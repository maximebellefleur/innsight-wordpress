<?php
/*Template name: Map Page */
?>
<!doctype html>
<html <?php language_attributes(); ?> class="">
	<head>
		<meta charset="<?php bloginfo( 'charset' ); ?>">
		<meta name="viewport" content="width=device-width, initial-scale=1, maximum-scale=1, user-scalable=0">
		<?php
		
		wp_head();
		
	?>
	</head>
	<body <?php body_class('app-loading'); ?> >
	<div class="loader"></div>
		<div class="map-wrap">
			<div class="container main-content">
				<div class="row">
					<!-- map row-->
					<?php echo do_shortcode('[custom_map location="Interlaken, Switzerland" zoom="10"]'); ?>
				</div><!--/row-->
					
						
			</div><!--/container-->

		</div><!--/home-wrap-->
<?php get_footer(); ?>