<?php
/*
Plugin Name: Yuna innSight
Description: Adds custom maps with Leaflet and registers points of interest.
Version: 1.0
Author: Yuna Design
*/

//DEMO : [custom_map viewmode="multi|blogs|single|act" height="50vh" taxonomy_slug="category" taxonomy_id="22"]
  
  new acf_save_json_based_on_group_key();
  
  class acf_save_json_based_on_group_key {
    
    // $groups is an array of field group key => path pairs
    // these will be set later
    private $groups = array();
    
    // this variable will store the current group key
    // that is being saved so that we can retrieve it later
    private $current_group_being_saved;
    
    public function __construct() {
      
      // this init action will set up the save paths
      add_action('admin_init', array($this, 'admin_init'));
      
      // this action is called by ACF before saving a field group
      // the priority is set to 1 so that it runs before the internal ACF action
      add_action('acf/update_field_group', array($this, 'update_field_group'), 1, 1);
      
    } // end public function __construct
    
    public function admin_init() {
      
      // in this function we set up the paths where we want to store JSON files
      // in this example we're creating two folders in the theme header and footer
      // change the field groups and keys based on your groups
      $footer = get_stylesheet_directory().'/modules/footer';
      $header = get_stylesheet_directory().'/modules/header';
      $this->groups = array(
        'group_584d5b7986f02' => $header,
        'group_584d5b7986f03' => $footer
      );
      
    } // end public function admin_init
    
    public function update_field_group($group) {
      // the purpose of this function is to see if we want to
      // change the location where this group is saved
      // and if we to to add a filter to alter the save path
      
      // first check to see if this is one of our groups
      if (!isset($this->groups[$group['key']])) {
        // not one or our groups
        return $group;
      }
      
      // store the group key and add action
      $this->current_group_being_saved = $group['key'];
      add_action('acf/settings/save_json',  array($this, 'override_json_location'), 9999);
      
      // don't forget to return the groups
      return $group;
      
    } // end public function update_field_group
    
    public function override_json_location($path) {
      
      // alter the path based on group being saved and
      // our save locations
      $path = $this->groups[$this->current_group_being_saved];
      
      return $path;
      
    } // end public function override_json_location
    
  } // end class acf_save_json_based_on_group_key

function yuna_innsight_acf_options_page_settings() {
    if( function_exists('acf_add_options_page') ) {
        acf_add_options_page(array(
            'page_title'    => 'Yuna InnSight Settings',
            'menu_title'    => 'Yuna InnSight',
            'menu_slug'     => 'yuna_innsight',
            'capability'    => 'manage_options',
            'redirect'      => false,
            'update_button' => __('Save Settings', 'acf'),
            'updated_message' => __("Settings Saved", 'acf'),
        ));
    }
}
add_action('acf/init', 'yuna_innsight_acf_options_page_settings');
function menu_shuffle() {
    remove_menu_page('yuna_innsight'); // Remove the menu item from its original location
    add_submenu_page(
        'options-general.php',          // Parent slug: "Settings" menu
        'Yuna InnSight Settings',       // Page title
        'Yuna InnSight',                // Menu title
        'manage_options',               // Capability
        'yuna_innsight'                 // Menu slug
    );
}
add_action('admin_menu', 'menu_shuffle', 100);

// Enqueue ACF scripts and styles
function yuna_innsight_enqueue_acf_scripts($hook) {
    if ($hook != 'settings_page_yuna_innsight') return;
    wp_enqueue_script('acf-input');
    wp_enqueue_script('acf-field-group');
    wp_enqueue_style('acf-global');
    wp_enqueue_style('acf-input');
    wp_enqueue_style('acf-field-group');
}
add_action('admin_enqueue_scripts', 'yuna_innsight_enqueue_acf_scripts');

function yuna_innsight_settings_page() {
    ?>
    <div class="wrap">
        <h1>Yuna InnSight Settings</h1>
        <?php acf_form(array(
            'post_id' => 'options',
            'field_groups' => array('group_55797d5741471'), // Add your ACF field group key here for map-related fields
            'submit_value' => 'Save Settings',
        )); ?>
    </div>
    <?php
}



//ACF RELATED
add_action('acf/init', function() {
    if (!function_exists('acf_add_local_field_group')) {
        return;
    }

    // Add POI Fields
    acf_add_local_field_group(array(
        'key' => 'group_6634df1b21de1',
        'title' => 'POI Fields',
        'fields' => array(
            array(
                'key' => 'field_6634df6a1e329',
                'label' => 'POI Latitude',
                'name' => 'poi_latitude',
                'type' => 'text',
                'required' => 0,
                'wrapper' => array('width' => '', 'class' => '', 'id' => ''),
            ),
            array(
                'key' => 'field_6634df851e32a',
                'label' => 'POI Longitude',
                'name' => 'poi_longitude',
                'type' => 'text',
                'required' => 0,
                'wrapper' => array('width' => '', 'class' => '', 'id' => ''),
            ),
            array(
                'key' => 'field_6634df921e32b',
                'label' => 'POI Type',
                'name' => 'poi_type',
                'type' => 'select',
                'choices' => array(
                    'food' => 'Restaurant',
                    'bar' => 'Bar',
                    'city' => 'City / Village / Town',
                    'place' => 'Place',
                    'transport' => 'Transport',
                    'hike' => 'Hike Start/End Point',
                    'shop' => 'Grocery or Shopping',
                    'public' => 'Police, Hospital, Public Buildings',
                    'land' => 'Landscape',
                ),
                'default_value' => false,
                'return_format' => 'value',
                'wrapper' => array('width' => '', 'class' => '', 'id' => ''),
            ),
            
            array(
                'key' => 'field_664fdd683bcc5',
                'label' => 'POI Category',
                'name' => 'poi_category',
                'aria-label' => '',
                'type' => 'select',
                'instructions' => '',
                'required' => 0,
                'conditional_logic' => 0,
                'wrapper' => array(
                    'width' => '',
                    'class' => '',
                    'id' => '',
                ),
                'choices' => array(
                    'md-local-airport' => 'Airport',
                    'md-beach-access' => 'Beach',
                    'map-amusement-park' => 'Amusement Park',
                    'map-aquarium' => 'Aquarium',
                    'map-art-gallery' => 'Art Gallery',
                    'map-atm' => 'ATM',
                    'map-bakery' => 'Bakery',
                    'map-bank' => 'Bank',
                    'map-bar' => 'Bar',
                    'map-baseball' => 'Baseball',
                    'map-beauty-salon' => 'Beauty Salon',
                    'map-bicycle-store' => 'Bicycle Store',
                    'map-boat-ramp' => 'Boat Ramp',
                    'map-boat-tour' => 'Boat Tour',
                    'map-boating' => 'Boating',
                    'map-book-store' => 'Book Store',
                    'map-bowling-alley' => 'Bowling Alley',
                    'md-directions-bus' => 'Bus Station',
                    'md-local-cafe' => 'Cafe',
                    'map-campground' => 'Campground',
                    'map-canoe' => 'Canoe',
                    'md-directions-car' => 'Car Rental',
                    'map-car-repair' => 'Car Repair',
                    'map-car-wash' => 'Car Wash',
                    'map-casino' => 'Casino',
                    'map-cemetery' => 'Cemetery',
                    'map-chairlift' => 'Chairlift',
                    'map-church' => 'Church',
                    'map-city-hall' => 'City Hall',
                    'md-location-city' => 'City / Village / Town',
                    'map-climbing' => 'Climbing', 
                    'md-local-mall' => 'Clothing Store',
                    'map-compass' => 'Compass',
                    'md-local-convenience-store' => 'Convenience Store',
                    'map-cross-country-skiing' => 'Cross Country Skiing',
                    'map-dentist' => 'Dentist',
                    'map-diving' => 'Diving',
                    'map-doctor' => 'Doctor',
                    'map-electrician' => 'Electrician',
                    'map-electronics-store' => 'Electronics Store',
                    'map-embassy' => 'Embassy',
                    'md-fastfood' => 'Fast Food',
                    'map-finance' => 'Finance',
                    'map-fire-station' => 'Fire Station',
                    'map-fishing-pier' => 'Fishing Pier',
                    'md-fitness-center' => 'Gym',
                    'map-florist' => 'Florist',
                    'map-food' => 'Food',
                    'map-funeral-home' => 'Funeral Home',
                    'map-furniture-store' => 'Furniture Store',
                    'map-gas-station' => 'Gas Station', 
                    'md-food-truck' => 'Food Truck',
                    'md-forest' => 'Forest',
                    'md-local-florist' => 'Flower Shop',
                    'md-local-grocery-store' => 'Grocery Store',
                    'md-hardware' => 'Hardware Store',
                    'map-gym' => 'Gym',
                    'map-hair-care' => 'Hair Care',
                    'map-hang-gliding' => 'Hang Gliding',
                    'map-health' => 'Health',
                    'map-hindu-temple' => 'Hindu Temple',
                    'md-hiking' => 'Hike',
                    'map-hospital' => 'Hospital',
                    'md-hotel' => 'Hotel',
                    'md-night-shelter' => 'Hostel',
                    'map-ice-fishing' => 'Ice Fishing',
                    'map-ice-skating' => 'Ice Skating',
                    'map-inline-skating' => 'Inline Skating',
                    'map-insurance-agency' => 'Insurance Agency',
                    'map-jet-skiing' => 'Jet Skiing',
                    'md-local-jewelry' => 'Jewelry Store',
                    'map-kayaking' => 'Kayaking',
                    'map-laundry' => 'Laundry',
                    'map-lawyer' => 'Lawyer',
                    'md-landscape' => 'Landscape',
                    'md-local-library' => 'Library',
                    'map-liquor-store' => 'Liquor Store',
                    'map-local-government' => 'Local Government',
                    'map-locksmith' => 'Locksmith',
                    'map-lodging' => 'Lodging',
                    'map-map-pin' => 'Map Pin',
                    'map-marina' => 'Marina',
                    'md-mosque' => 'Mosque',
                    'map-movie-rental' => 'Movie Rental',
                    'map-movie-theater' => 'Movie Theater',
                    'md-museum' => 'Museum',
                    'map-natural-feature' => 'Natural Feature',
                    'md-nightlife' => 'Night Club', 
                    'md-park' => 'Park',
                    'md-pets' => 'Pet Store',
                    'md-local-pharmacy' => 'Pharmacy',
                    'map-place-of-worship' => 'Place of Worship',
                    'md-place' => 'Place',
                    'map-playground' => 'Playground',
                    'map-point-of-interest' => 'Point of Interest',
                    'map-political' => 'Political',
                    'md-local-police' => 'Police, Hospital, Public Buildings',
                    'map-post-office' => 'Post Office',
                    'map-rafting' => 'Rafting',
                    'map-real-estate-agency' => 'Real Estate Agency',
                    'md-restaurant' => 'Restaurant',
                    'map-route' => 'Route',
                    'map-route-pin' => 'Route Pin',
                    'map-rv-park' => 'RV Park',
                    'map-sailing' => 'Sailing',
                    'md-river' => 'River/Lake/Water',
                    'md-school' => 'School',
                    'map-scuba-diving' => 'Scuba Diving',
                    'md-sports-stadium' => 'Stadium',
                    'map-skateboarding' => 'Skateboarding',
                    'map-ski-jumping' => 'Ski Jumping',
                    'map-skiing' => 'Skiing',
                    'map-sledding' => 'Sledding',
                    'map-snow' => 'Snow',
                    'map-snow-shoeing' => 'Snow Shoeing',
                    'map-snowboarding' => 'Snowboarding',
                    'map-snowmobile' => 'Snowmobile',
                    'map-spa' => 'Spa',
                    'map-stadium' => 'Stadium',
                    'map-storage' => 'Storage',
                    'map-store' => 'Store',
                    'md-streetview' => 'Street Food',
                    'md-subway' => 'Subway Station',
                    'map-surfing' => 'Surfing',
                    'map-swimming' => 'Swimming',
                    'md-synagogue' => 'Synagogue',
                    'map-taxi-stand' => 'Taxi Stand',
                    'map-tennis' => 'Tennis',
                    'map-toilet' => 'Toilet',
                    'md-temple' => 'Temple',
                    'map-transit-station' => 'Transit Station',
                    'map-travel-agency' => 'Travel Agency',
                    'md-train' => 'Train Station',
                    'map-university' => 'University',
                    'map-waterskiing' => 'Waterskiing',
                    'map-whale-watching' => 'Whale Watching',
                    'map-wheelchair' => 'Wheelchair',
                    'map-wind-surfing' => 'Wind Surfing',
                    'md-wine-bar' => 'Wine Bar',
                    'md-zoo' => 'Zoo'
                ),              
                'default_value' => false,
                'return_format' => 'value',
                'wrapper' => array('width' => '', 'class' => '', 'id' => '')
            ),
            array(
                'key' => 'field_6638ec6ff3b09',
                'label' => 'POI Image',
                'name' => 'poi_image',
                'type' => 'image',
                'return_format' => 'id',
                'library' => 'all',
                'preview_size' => 'thumbnail',
                'wrapper' => array('width' => '', 'class' => '', 'id' => ''),
            ),
            array(
                'key' => 'field_4499df6a1e123',
                'label' => 'POI Custom Link',
                'name' => 'poi_url_link',
                'aria-label' => '',
                'type' => 'link',
                'instructions' => '',
                'required' => 0,
                'conditional_logic' => 0,
                'wrapper' => array(
                    'width' => '',
                    'class' => '',
                    'id' => '',
                ),
                'return_format' => 'array',
            ),
        ),
        'location' => array(
            array(
                array(
                    'param' => 'taxonomy',
                    'operator' => '==',
                    'value' => 'point_of_interest',
                ),
            ),
        ),
        'menu_order' => 0,
        'position' => 'acf_after_title',
        'style' => 'default',
        'label_placement' => 'top',
        'instruction_placement' => 'label',
        'active' => true,
    ));

    // Add Maps Related Fields
    acf_add_local_field_group(array(
        'key' => 'group_55797d5741471',
        'title' => 'GENERAL FIELDS',
        'fields' => array(
            array(
                'key' => 'field_663d481f06496',
                'label' => 'Maps Bg Img',
                'name' => 'maps_bg_img',
                'type' => 'image',
                'required' => 1,
                'return_format' => 'id',
                'library' => 'all',
                'preview_size' => 'medium',
                'wrapper' => array('width' => '', 'class' => '', 'id' => ''),
            ),
            array(
                'key' => 'field_663d485306497',
                'label' => 'Maps Titre',
                'name' => 'maps_titre',
                'type' => 'text',
                'required' => 1,
                'wrapper' => array('width' => '', 'class' => '', 'id' => ''),
            ),
            array(
                'key' => 'field_663d486806498',
                'label' => 'Maps Text',
                'name' => 'maps_text',
                'type' => 'wysiwyg',
                'required' => 1,
                'toolbar' => 'basic',
                'media_upload' => 0,
                'wrapper' => array('width' => '', 'class' => '', 'id' => ''),
            ),
            array(
                'key' => 'field_663d488006499',
                'label' => 'Maps More Info URL',
                'name' => 'maps_more_info_url',
                'type' => 'link',
                'required' => 1,
                'return_format' => 'array',
                'wrapper' => array('width' => '', 'class' => '', 'id' => ''),
            ),
            array(
                'key' => 'field_456d575306497',
                'label' => 'Default Latitude',
                'name' => 'maps_latitude',
                'type' => 'text',
                'required' => 1,
                'wrapper' => array('width' => '', 'class' => '', 'id' => ''),
            ),
            array(
                'key' => 'field_456f575301234',
                'label' => 'Default Longitude',
                'name' => 'maps_longitude',
                'type' => 'text',
                'required' => 1,
                'wrapper' => array('width' => '', 'class' => '', 'id' => ''),
            ),
        ),
        'location' => array(
            array(
                array(
                    'param' => 'options_page',
                    'operator' => '==',
                    'value' => 'yuna_innsight',
                ),
            ),
        ),
        'menu_order' => 0,
        'position' => 'acf_after_title',
        'style' => 'default',
        'label_placement' => 'top',
        'instruction_placement' => 'label',
        'hide_on_screen' => array('permalink', 'the_content', 'excerpt', 'discussion', 'comments', 'revisions', 'slug', 'author', 'format', 'page_attributes', 'featured_image', 'categories', 'tags', 'send-trackbacks'),
        'active' => true,
    ));

    //Add Maps Shortcode Fields
    acf_add_local_field_group( array(
        'key' => 'group_66341b30cd653',
        'title' => 'Single Post Maps',
        'fields' => array(
            array(
                'key' => 'field_66341b31f5912',
                'label' => 'Add a map to your post?',
                'name' => 'map_to_post',
                'aria-label' => '',
                'type' => 'true_false',
                'instructions' => '',
                'required' => 0,
                'conditional_logic' => 0,
                'wrapper' => array(
                    'width' => '',
                    'class' => '',
                    'id' => '',
                ),
                'message' => '',
                'default_value' => 0,
                'ui' => 0,
                'ui_on_text' => '',
                'ui_off_text' => '',
            ),
            array(
                'key' => 'field_66341edb44073',
                'label' => 'Map Base Location',
                'name' => 'map_base_location',
                'aria-label' => '',
                'type' => 'text',
                'instructions' => '',
                'required' => 1,
                'conditional_logic' => array(
                    array(
                        array(
                            'field' => 'field_66341b31f5912',
                            'operator' => '==',
                            'value' => '1',
                        ),
                    ),
                ),
                'wrapper' => array(
                    'width' => '50',
                    'class' => '',
                    'id' => '',
                ),
                'default_value' => 'Interlaken',
                'maxlength' => '',
                'placeholder' => '',
                'prepend' => '',
                'append' => '',
            ),
            array(
                'key' => 'field_66341eee44074',
                'label' => 'Map Zoom Level',
                'name' => 'map_zoom_level',
                'aria-label' => '',
                'type' => 'number',
                'instructions' => '',
                'required' => 1,
                'conditional_logic' => array(
                    array(
                        array(
                            'field' => 'field_66341b31f5912',
                            'operator' => '==',
                            'value' => '1',
                        ),
                    ),
                ),
                'wrapper' => array(
                    'width' => '50',
                    'class' => '',
                    'id' => '',
                ),
                'default_value' => 12,
                'min' => 1,
                'max' => 20,
                'placeholder' => '',
                'step' => '',
                'prepend' => '',
                'append' => '',
            ),
            array(
                'key' => 'field_6634383a6d89e',
                'label' => 'Map Quick Name',
                'name' => 'map_quick_name',
                'aria-label' => '',
                'type' => 'text',
                'instructions' => 'Use format FROM_LOCATION_NAME >> TO_LOCATION_NAME (LEVEL) <br />
                EX: Rothorn Brienzer >> Harder Klum (difficult)',
                'required' => 1,
                'conditional_logic' => array(
                    array(
                        array(
                            'field' => 'field_66341b31f5912',
                            'operator' => '==',
                            'value' => '1',
                        ),
                    ),
                ),
                'wrapper' => array(
                    'width' => '',
                    'class' => '',
                    'id' => '',
                ),
                'default_value' => '',
                'maxlength' => '',
                'placeholder' => '',
                'prepend' => '',
                'append' => '',
            ),
            array(
                'key' => 'field_66341b5cf5913',
                'label' => 'Add Markers?',
                'name' => 'maps_add_markers',
                'aria-label' => '',
                'type' => 'true_false',
                'instructions' => '',
                'required' => 0,
                'conditional_logic' => array(
                    array(
                        array(
                            'field' => 'field_66341b31f5912',
                            'operator' => '==',
                            'value' => '1',
                        ),
                    ),
                ),
                'wrapper' => array(
                    'width' => '50',
                    'class' => '',
                    'id' => '',
                ),
                'message' => '',
                'default_value' => 0,
                'ui' => 0,
                'ui_on_text' => '',
                'ui_off_text' => '',
            ),
            array(
                'key' => 'field_66341b92f5914',
                'label' => 'Add Paths?',
                'name' => 'maps_add_paths',
                'aria-label' => '',
                'type' => 'true_false',
                'instructions' => '',
                'required' => 0,
                'conditional_logic' => array(
                    array(
                        array(
                            'field' => 'field_66341b31f5912',
                            'operator' => '==',
                            'value' => '1',
                        ),
                    ),
                ),
                'wrapper' => array(
                    'width' => '50',
                    'class' => '',
                    'id' => '',
                ),
                'message' => '',
                'default_value' => 0,
                'ui' => 0,
                'ui_on_text' => '',
                'ui_off_text' => '',
            ),
            array(
                'key' => 'field_6634a8e1299ac',
                'label' => 'Existing Activity Markers',
                'name' => 'maps_existing_act_marker_id',
                'aria-label' => '',
                'type' => 'post_object',
                'instructions' => '',
                'required' => 0,
                'conditional_logic' => array(
                    array(
                        array(
                            'field' => 'field_66341b5cf5913',
                            'operator' => '==',
                            'value' => '1',
                        ),
                    ),
                ),
                'wrapper' => array(
                    'width' => '50',
                    'class' => '',
                    'id' => '',
                ),
                'post_type' => array(
                    0 => 'portfolio',
                ),
                'post_status' => '',
                'taxonomy' => '',
                'return_format' => 'id',
                'multiple' => 1,
                'allow_null' => 1,
                'bidirectional' => 0,
                'ui' => 1,
                'bidirectional_target' => array(
                ),
            ),
            array(
                'key' => 'field_6634b3a006d7b',
                'label' => 'Point of Interested Markers',
                'name' => 'maps_poi_markers',
                'aria-label' => '',
                'type' => 'taxonomy',
                'instructions' => '',
                'required' => 0,
                'conditional_logic' => array(
                    array(
                        array(
                            'field' => 'field_66341b5cf5913',
                            'operator' => '==',
                            'value' => '1',
                        ),
                    ),
                ),
                'wrapper' => array(
                    'width' => '50',
                    'class' => '',
                    'id' => '',
                ),
                'taxonomy' => 'point_of_interest',
                'add_term' => 1,
                'save_terms' => 1,
                'load_terms' => 1,
                'return_format' => 'object',
                'field_type' => 'multi_select',
                'allow_null' => 1,
                'bidirectional' => 0,
                'multiple' => 0,
                'bidirectional_target' => array(
                ),
            ),
            array(
                'key' => 'field_66341c31f5919',
                'label' => 'Paths Box',
                'name' => 'maps_paths_box',
                'aria-label' => '',
                'type' => 'repeater',
                'instructions' => '',
                'required' => 0,
                'conditional_logic' => array(
                    array(
                        array(
                            'field' => 'field_66341b92f5914',
                            'operator' => '==',
                            'value' => '1',
                        ),
                    ),
                ),
                'wrapper' => array(
                    'width' => '100',
                    'class' => '',
                    'id' => '',
                ),
                'layout' => 'table',
                'pagination' => 0,
                'min' => 0,
                'max' => 0,
                'collapsed' => '',
                'button_label' => 'Add Path',
                'rows_per_page' => 20,
                'sub_fields' => array(
                    array(
                        'key' => 'field_66341c31f591a',
                        'label' => 'Points Name',
                        'name' => 'maps_path_points_name',
                        'aria-label' => '',
                        'type' => 'text',
                        'instructions' => 'enter each location of the path, separated by // <br />
                        Ex: interlaken//bern//lausanne',
                        'required' => 1,
                        'conditional_logic' => 0,
                        'wrapper' => array(
                            'width' => '',
                            'class' => '',
                            'id' => '',
                        ),
                        'default_value' => '',
                        'maxlength' => '',
                        'placeholder' => '',
                        'prepend' => '',
                        'append' => '',
                        'parent_repeater' => 'field_66341c31f5919',
                    ),
                ),
            ),
        ),
        'location' => array(
            array(
                array(
                    'param' => 'post_type',
                    'operator' => '==',
                    'value' => 'post',
                ),
            ),
        ),
        'menu_order' => 0,
        'position' => 'normal',
        'style' => 'default',
        'label_placement' => 'top',
        'instruction_placement' => 'label',
        'hide_on_screen' => '',
        'active' => true,
        'description' => '',
        'show_in_rest' => 0,
    ) );
    
    
});

//////>>>> Function to get the post URL and text
function get_poi_post_url_and_text($term_id) {
    // Check if the result is cached
    $cache_key = 'poi_post_' . $term_id;
    $cached_result = get_transient($cache_key);

    if ($cached_result !== false) {
        return $cached_result;
    }

    // Query to get the post
    $query = new WP_Query(array(
        'post_type' => 'post',
        'tax_query' => array(
            array(
                'taxonomy' => 'point_of_interest',
                'field' => 'term_id',
                'terms' => $term_id,
            ),
        ),
        'posts_per_page' => 1,
        'fields' => 'ids', // Only get post IDs
    ));

    // Prepare the result
    if ($query->have_posts()) {
        $post_id = $query->posts[0];
        $result = array(
            'btn_url' => get_permalink($post_id),
            'btn_txt' => 'more information',
        );
    } else {
        $result = false;
    }

    // Cache the result for 12 hours
    set_transient($cache_key, $result, 48 * HOUR_IN_SECONDS);

    return $result;
}
//--


//MAPS FUNCTIONS
//...shortcode
//FIELDS: 'location' => '', 'zoom' => '', 'viewmode' => 'single/act', 'height' => '70vh', 'taxonomy_slug' => '', 'taxonomy_id' => ''
function add_custom_map_shortcode($atts) {
    global $my_transposh_plugin;
    $currentlang = transposh_get_current_language();

    // Enqueue Leaflet scripts and styles
    wp_enqueue_script('leaflet', 'https://unpkg.com/leaflet/dist/leaflet.js', array(), false, true);
    wp_enqueue_style('leaflet', 'https://unpkg.com/leaflet/dist/leaflet.css');
    wp_enqueue_style('leaflet-gesture', 'https://unpkg.com/leaflet-gesture-handling/dist/leaflet-gesture-handling.min.css');
    wp_enqueue_script('leaflet-gesture', 'https://unpkg.com/leaflet-gesture-handling', array(), false, true);
    wp_enqueue_script('leaflet-fullscreen', plugin_dir_url(__FILE__) . 'js/Control.FullScreen.js', array(), false, true);
    wp_enqueue_style('leaflet-fullscreen',plugin_dir_url(__FILE__) . 'css/Control.FullScreen.css');
    //wp_enqueue_style('baseline', plugin_dir_url(__FILE__) . 'css/baseline.css');

    wp_enqueue_style('leaflet-markercluster', 'https://unpkg.com/leaflet.markercluster@1.4.1/dist/MarkerCluster.css');
    wp_enqueue_style('leaflet-markercluster-default', 'https://unpkg.com/leaflet.markercluster@1.4.1/dist/MarkerCluster.Default.css');
    wp_enqueue_script('leaflet-markercluster', 'https://unpkg.com/leaflet.markercluster@1.4.1/dist/leaflet.markercluster.js', array(), false, true);
    wp_enqueue_script('leaflet-markercluster-layer', plugin_dir_url(__FILE__) . 'js/leaflet.markercluster.layersupport.js', array(), false, true);
    wp_enqueue_script('leaflet-markercluster-sub', plugin_dir_url(__FILE__) . 'js/subgroup.js', array(), false, true);

    // register your script location, dependencies and version
    wp_register_script('innsight_script', plugin_dir_url(__FILE__) . 'js/yuna-innsight-settings.js',  array('jquery'), '1.0', true);
    wp_enqueue_script('innsight_script');
    wp_localize_script( 'innsight_script', 'innsightajax', array( 'ajaxurl' => admin_url( 'admin-ajax.php' )));

    //Set default attributes and merge with input
    $attributes = shortcode_atts(
        array('post_id' => get_the_ID(),
        'location' => '',
        'zoom' => '',
        'viewmode' => '',
        'height' => '70vh',
        'taxonomy_slug' => '', 
        'taxonomy_id' => '',
    ), $atts);
    $acf_fields = get_fields($attributes['post_id']);
    $viewmode = ($attributes['viewmode']) ? $attributes['viewmode'] : 'multi';
    $mapheight = ($attributes['height']) ? $attributes['height'] : '70vh';
    $taxonomy_slug = ($attributes['taxonomy_slug']) ? $attributes['taxonomy_slug'] : '';
    $taxonomy_id = ($attributes['taxonomy_id']) ? $attributes['taxonomy_id'] : '';

    //Retriew Location of Map
    //$location = ( empty( $attributes['location'] ) ) ? $acf_fields['map_base_location'] : $attributes['location'];
    $location = (empty($attributes['location']) && isset($acf_fields['map_base_location'])) ? $acf_fields['map_base_location'] : $attributes['location'];

    if(empty($location)){$location = 'Interlaken';}

    //Retrieve zoom level
    //$zoomLevel = (empty($attributes['zoom'])) ? $acf_fields['map_zoom_level'] : $attributes['zoom'];
    $zoomLevel = (empty($attributes['zoom']) && isset($acf_fields['map_zoom_level'])) ? $acf_fields['map_zoom_level'] : ($attributes['zoom'] ?? null);

    if(empty($zoomLevel)){ $zoomLevel = 12;}

    //Set Map Locations
    $latlon = convert_name_to_lat_lon($location);
    $lat = $latlon['lat'];
    $lon = $latlon['lon'];

    if($viewmode == 'event'){

        //buildup markers
        $leaflet_markers = array();
        $post_id = get_the_ID(); 
        $location_coords = explode(',', $location);

        $custom_event_btn_title = get_post_meta($post_id, 'single_event_button', true);
        $custom_event_btn_title = ($custom_event_btn_title) ? $custom_event_btn_title : 'more information';
        $custom_event_link = get_post_meta($post_id, 'single_event_button_link', true);
        $custom_event_link = ($custom_event_link) ? $custom_event_link : get_permalink($post_id);
        //$custom_event_btn_target = (get_post_meta($post_id, 'single_event_where_to', true)) ? 'target=_blank' : '';
        //$custom_event_btn = ($custom_event_link && $custom_event_btn_title) ? ' <a href="'.$custom_event_link.'" '.$custom_event_btn_target.'>'.$custom_event_btn_title.'</a>' : '';
        $leaflet_markers[] = [
            'title' => translated_by_yuna(get_the_title($post_id)),
            'lat' => $location_coords[0],
            'lon' => $location_coords[1],
            'desc' => translated_by_yuna(wp_trim_words( get_post_meta($post_id,'single_event_gallery_description', true), 20, '...' )),
            'type' => 'event',
            'img' => get_the_post_thumbnail_url($post_id, 'large'),
            'btn_text' => translated_by_yuna($custom_event_btn_title),
            'btn_url' => $custom_event_link,//(get_permalink($post_id)),
        ];

    }elseif($viewmode == 'single'){//in single blog post default or custom page manually

        //1. custom POI markers
        $leaflet_markers = array();
        if($acf_fields['maps_add_markers']){

            $leaflet_markers = [];
            $post_id = get_the_ID(); // Get the current post ID
            $terms = get_the_terms($post_id, 'point_of_interest'); // Get the terms

            if ($terms && !is_wp_error($terms)) { // Check if any terms were found
                foreach ($terms as $term) {
                    $poi_url_link = get_term_meta($term->term_id, 'poi_url_link', true); // Define $poi_url_link inside the loop

                    $leaflet_markers[] = [
                        'title' => translated_by_yuna($term->name),
                        'lat' => get_term_meta($term->term_id,'poi_latitude', true),
                        'lon' => get_term_meta($term->term_id,'poi_longitude', true),
                        'desc' => translated_by_yuna($term->description),
                        'btn_url' => is_array($poi_url_link) && isset($poi_url_link['url']) ? $poi_url_link['url'] : '',
                        'type' => get_term_meta($term->term_id,'poi_type', true),
                        'category' => get_term_meta($term->term_id, 'poi_category', true),
                        'img' => wp_get_attachment_image_url(get_term_meta($term->term_id,'poi_image', true),'large'),
                    ];
                }
            }

        }

        //2. add selected activities
        if($acf_fields['maps_existing_act_marker_id']){

            //default args
            $args = array(
                'post_type' => 'portfolio',
                'post_status' => 'publish',
                'post__in'       => $acf_fields['maps_existing_act_marker_id'],
                'posts_per_page' => -1,
            );

            $posts = get_posts($args);

            // Process each activity
            foreach ($posts as $post) {
                $lat = get_post_meta($post->ID, 'latitude', true);
                $lat = ($lat) ? $lat : '46.68132974996898';
                $lon = get_post_meta($post->ID, 'longitude', true);
                $lon = ($lon) ? $lon : '7.8639847277626185';
                $new_marker = [
                    'title' => translated_by_yuna(get_the_title($post->ID)),
                    'lat' => $lat,
                    'lon' => $lon,
                    'desc' => translated_by_yuna(get_post_meta($post->ID, 'activity_main_slogan', true)),
                    'type' => 'activities',
                    'img' => get_the_post_thumbnail_url($post->ID, 'large'),
                    'btn_text' => translated_by_yuna('more information'),
                    'btn_url' => get_lang_url(get_permalink($post->ID)),
                ];
                $leaflet_markers[] = $new_marker;
            }
            wp_reset_postdata();  // Resets the post data to the original query

        }


        //buildup paths
        $leaflet_paths = array();
        if($acf_fields['maps_add_paths']){
            $paths = $acf_fields['maps_paths_box'];
            $leaflet_paths = [];
        
            if($paths) {
                foreach($paths as $path) {
                    $points = explode('//', $path['maps_path_points_name']); // Split the points string into an array
                    $coordinates = [];
        
                    foreach($points as $point) {
                        // Check if the point is already in the format of coordinates
                        if (preg_match('/^-?\d{1,3}\.\d+,-?\d{1,3}\.\d+$/', $point)) {
                            $coordinates[] = $point;
                        } else {
                            // Use a geocoding service to convert the location name to coordinates
                            $latLon = convert_name_to_lat_lon($point);
                            $coordinates[] = $latLon['lat'] . ',' . $latLon['lon'];
                        }
                    }

                    $leaflet_paths[] = [
                        'title' => 'Directions',
                        'color' => '#f00',
                        'coordinates' => $coordinates,
                    ];
                }
            }
        }
    }else if($viewmode == 'act'){ //in activities page

        //default args
        $args = array(
            'post_type' => 'portfolio',
            'post_status' => 'publish',
            'post__not_in' => array($attributes['post_id']),//except current post
            'posts_per_page' => -1,  // -1 to get all posts
            'orderby' => 'rand',
            'meta_query' => array(
                'relation' => 'AND',
                array(
                    'key' => 'latitude',
                    'value' => '',  // Check that the key is not empty
                    'compare' => '!=',  // NOT EQUAL TO empty
                ),
                array(
                    'key' => 'longitude',
                    'value' => '',  // Check that the key is not empty
                    'compare' => '!=',  // NOT EQUAL TO empty
                )
            )
        );

        $posts = get_posts($args);

        // Process each post
        $leaflet_markers = [];
        foreach ($posts as $post) {
            $lat = get_post_meta($post->ID, 'latitude', true);
            $lat = ($lat) ? $lat : '46.68132974996898';
            $lon = get_post_meta($post->ID, 'longitude', true);
            $lon = ($lon) ? $lon : '7.8639847277626185';
            $new_marker = [
                'title' => translated_by_yuna(get_the_title($post->ID)),
                'lat' => $lat,
                'lon' => $lon,
                'desc' => translated_by_yuna(get_post_meta($post->ID, 'activity_main_slogan', true)),
                'type' => 'activities',
                'img' => get_the_post_thumbnail_url($post->ID, 'large'),
                'btn_text' => translated_by_yuna('more information'),
                'btn_url' => get_lang_url(get_permalink($post->ID)),
            ];
            $leaflet_markers[] = $new_marker;
        }
        wp_reset_postdata();  // Resets the post data to the original query

        //check if current post is of portfolio type
        $current_post = get_post();
        if($current_post->post_type == 'portfolio'){
            $act_lat = get_post_meta($current_post->ID, 'latitude', true);
            $act_lat = ($act_lat) ? $act_lat : '46.68132974996898';
            $act_lon = get_post_meta($current_post->ID, 'longitude', true);
            $act_lon = ($act_lon) ? $act_lon : '7.8639847277626185';
            $new_marker = [
                'title' => translated_by_yuna(get_the_title($current_post->ID)),
                'lat' => $act_lat,
                'lon' => $act_lon,
                'desc' => translated_by_yuna(get_post_meta($current_post->ID, 'activity_main_slogan', true)),
                'type' => 'current',
                'img' => get_the_post_thumbnail_url($current_post->ID, 'large'),
            ];
            $leaflet_markers[] = $new_marker;

            //center map on current post
            $lat = $act_lat;
            $lon = $act_lon;
        }
        wp_reset_postdata();

        $leaflet_paths = [];

    }else { //regroup many poi, activities and events (tagged as poi)

        //default args
        $args = array(
            'post_type' => 'post',
            'post_status' => 'publish',
            'posts_per_page' => -1,  // -1 to get all posts
        );

        // If taxonomy slug and ID are provided, modify the query
        if (!empty($attributes['taxonomy_slug']) && !empty($attributes['taxonomy_id'])) {
            $args['tax_query'] = array(
                array(
                    'taxonomy' => $attributes['taxonomy_slug'],
                    'field' => 'term_id',
                    'terms' => array($attributes['taxonomy_id'])
                )
            );
        }

        $posts = get_posts($args);

        // Check if a marker is a duplicate
        function is_duplicate_marker($markers, $new_marker) {
            foreach ($markers as $marker) {
                if ($marker['lat'] === $new_marker['lat'] && $marker['lon'] === $new_marker['lon'] && $marker['title'] === $new_marker['title']) {
                    return true;
                }
            }
            return false;
        }

        //setting markers type
        $poi_types = []; // Array to hold the poi_type values
        $leaflet_markers = [];  // Array to hold the markers data
        $link_checker = false;
        
        foreach ($posts as $post) {
            //retrieve all taxonomy poi
            $terms = get_the_terms($post->ID, 'point_of_interest');
            if ($terms && !is_wp_error($terms)) {
                foreach ($terms as $term) {
                    $term_type = get_term_meta($term->term_id, 'poi_type', true);
                    $term_category = get_term_meta($term->term_id, 'poi_category', true);
                    $current_post_url = get_permalink();
                    $btn_url = ''; 
                    $btn_txt = '';
                    
                    // Get post data related to the taxonomy
                    //$post_data = get_poi_post_url_and_text($term->term_id);

                    //Check if current post URL matches $man_selected_btn_url or $post_data['btn_url']
                    if (!empty($current_post_url)) {
                        $man_selected_btn_url = get_term_meta($term->term_id,'main_more_info_url', true);
                        $btn_info = get_term_meta($term->term_id,'poi_url_link', true);
                        if ($man_selected_btn_url && ($current_post_url == $man_selected_btn_url) ) {//if current page match selected url, give external info
                            if (!empty($btn_info) && !empty($btn_info['url'])) {
                                $btn_url = $btn_info['url'];
                                $btn_txt = (!empty($btn_info['title'])) ? $btn_info['title'] : 'more information';
                                $link_checker = false;
                            }
                        }else {//else, return on-site url
                            if(!empty($man_selected_btn_url)){
                                $btn_url = $man_selected_btn_url;
                                $btn_txt = 'more information';
                                $link_checker = true;
                            }else {
                                $post_data = get_poi_post_url_and_text($term->term_id);
                                if ($post_data) {
                                    $btn_url = $post_data['btn_url'];
                                    $btn_txt = $post_data['btn_txt'];
                                    $link_checker = true;//if we use term relate content as button, mark it so we can include the link in description
                                }
                            }
                        }
                    }
                    
                    
                    //if($man_selected_btn_url){
                    //    $btn_url = $man_selected_btn_url;
                    //    $btn_txt = 'more information';
                    //}else if ($post_data) {
                    //    $btn_url = $post_data['btn_url'];
                    //    $btn_txt = $post_data['btn_txt'];
                    //    $link_checker = true;//if we use term relate content as button, mark it so we can include the link in description
                    //} else if (!empty($btn_info) && !empty($btn_info['url'])) {
                    //    $btn_url = $btn_info['url'];
                    //    $btn_txt = (!empty($btn_info['title'])) ? $btn_info['title'] : 'more information';
                    //}else {
                    //    $btn_url = '';
                    //    $btn_txt = '';
                    //}

                    //$description = ($link_checker && $btn_info['url'] && $btn_info['title']) ? $term->description.' <a href="'.$btn_info['url'].'">'.$btn_info['title'].'</a>' : $term->description;
                    $description = (is_array($btn_info) && $link_checker && !empty($btn_info['url']) && !empty($btn_info['title'])) 
    ? $term->description . ' <a href="' . esc_url($btn_info['url']) . '">' . esc_html($btn_info['title']) . '</a>' 
    : $term->description;
                     
                    $new_marker = [
                        'title' => translated_by_yuna($term->name),
                        'lat' => get_term_meta($term->term_id, 'poi_latitude', true),
                        'lon' => get_term_meta($term->term_id, 'poi_longitude', true),
                        'desc' => translated_by_yuna($description),
                        'type' => $term_type,
                        'category' => $term_category,
                        'img' => wp_get_attachment_image_url(get_term_meta($term->term_id, 'poi_image', true), 'large'),
                        'btn_url' => $btn_url,
                        'btn_text' => translated_by_yuna($btn_txt),
                    ];
                    if (!is_duplicate_marker($leaflet_markers, $new_marker)) {
                        $leaflet_markers[] = $new_marker;
                    }
                    if (!in_array($term_type, $poi_types)) {
                        $poi_types[] = $term_type;
                    }
                }
            }

            //retrieve all event category, if trigger field (event_poi) is true, grab lat/lon + info
            if (has_term('event', 'category', $post->ID)) {
                $event_poi = get_post_meta($post->ID, 'event_poi', true);
                if ($event_poi) {
                    $lat = get_post_meta($post->ID, 'latitude', true);
                    $lon = get_post_meta($post->ID, 'longitude', true);
                    $leaflet_markers[] = [
                        'title' => translated_by_yuna(get_the_title($post->ID)),
                        'lat' => $lat,
                        'lon' => $lon,
                        'desc' => translated_by_yuna(wp_trim_words(get_post_meta($post->ID, 'single_event_gallery_description', true), 20, '...')),
                        'type' => 'event',
                        'img' => get_the_post_thumbnail_url($post->ID, 'large'),
                        'btn_text' => translated_by_yuna('more information'),
                        'btn_url' => get_lang_url(get_permalink($post->ID)),
                    ];
                }
            }
            
        }

        wp_reset_postdata();

        if($viewmode !== 'blogs'){
            // Set default args for fetching portfolio posts
            $args2 = array(
                'post_type'      => 'portfolio',  // Your custom post type
                'post_status'    => 'publish',
                'posts_per_page' => -1,           // Retrieve all posts, alternative to 'numberposts'
                'meta_query'     => array(
                    'relation' => 'AND',
                    array(
                        'key'     => 'latitude',
                        'value'   => '',            // Check that the key is not empty
                        'compare' => '!=',          // NOT EQUAL TO empty
                    ),
                    array(
                        'key'     => 'longitude',
                        'value'   => '',            // Check that the key is not empty
                        'compare' => '!=',          // NOT EQUAL TO empty
                    )
                )
            );

            $posts = get_posts($args2);

            // Process each post
            foreach ($posts as $post) {
                $post_type = 'activities';
                $post_category = 'stabilization-action';
                $new_marker = [
                    'title' => translated_by_yuna(get_the_title($post->ID)),  // Corrected from post->post_id to post->ID
                    'lat' => get_post_meta($post->ID, 'latitude', true),
                    'lon' => get_post_meta($post->ID, 'longitude', true),
                    'desc' => translated_by_yuna(get_post_meta($post->ID, 'activity_main_slogan', true)),
                    'type' => $post_type,
                    'category' => $post_category,
                    'img' => get_the_post_thumbnail_url($post->ID, 'large'),  // Corrected from post->post_id to post->ID
                    'btn_text' => translated_by_yuna('more information'),
                    'btn_url' => get_lang_url(get_permalink($post->ID)),
                ];
                if (!is_duplicate_marker($leaflet_markers, $new_marker)) {
                    $leaflet_markers[] = $new_marker;
                }
                if (!in_array($post_type, $poi_types)) {
                    $poi_types[] = $post_type;
                }
            }
            wp_reset_postdata();  // Resets the post data to the original query

        }

        $leaflet_paths = [];
    }

    //set hostel as default
    $maps_link = get_field('maps_more_info_url', 'option');
    $leaflet_markers[] = [
    'title' => translated_by_yuna(get_field('maps_titre', 'option')),
    'lat' => get_field('maps_latitude', 'option'),
    'lon' => get_field('maps_longitude', 'option'),
    'desc' => translated_by_yuna(preg_replace('/<\/?p\b[^>]*>/i', '', get_field('maps_text', 'option'))),
    'type' => 'hostel',
    'img' => wp_get_attachment_image_url(get_field('maps_bg_img', 'option'), 'medium'),
    'btn_text' => translated_by_yuna($maps_link['title']),
    'btn_url' => $maps_link['url'],
    ];

    // Localize the script with data for JavaScript
    $poi_category = isset($poi_category) ? $poi_category : ''; 
    $poi_types = $poi_types ?? [];
    wp_localize_script('leaflet', 'mapData', array(
        'lat' => $lat,
        'lon' => $lon,
        'zoom' => $zoomLevel,
        'add_paths' => $leaflet_paths,
        'add_markers' => $leaflet_markers,  // Placeholder for markers data
        'types' => $poi_types,
        'category' => $poi_category, 
    ));
    wp_localize_script('leaflet', 'mapMarkers', $leaflet_markers);
    wp_localize_script('leaflet', 'mapPaths', $leaflet_paths);

    // Return the HTML for the map container
    $export_map_layout = '<div class="map_container">';
    $export_map_layout .= '<style>.mapIcon icon.fa-hostel:after {background: url('.esc_url(get_site_icon_url(512)).');}</style>';
    $export_map_layout .= '<h2>Here is a Map for you</h2>';
    $export_map_layout .= '<div id="map" style="height:'.$mapheight.';margin-bottom: 20px;"></div>';

    // Make the file downloadable
    $export_map_layout .= '<a href="javascript:void(0)" class="btnro app_trigger" data-markers="'.htmlspecialchars(serialize($leaflet_markers)).'" data-paths="'.htmlspecialchars(serialize($leaflet_paths)).'" data-postid="'.$attributes['post_id'].'" data-altname="Open in App">Get Map on your phone</a>';

    $export_map_layout .= '</div>';
    
    return $export_map_layout;
}
add_shortcode('custom_map', 'add_custom_map_shortcode');

add_action('wp_ajax_generate_kml', 'generate_kml');
add_action('wp_ajax_nopriv_generate_kml', 'generate_kml');
function generate_kml() {
    $attributes['post_id'] = $_REQUEST['post_id'];

    // Fetch your map data
    $markers = get_field('maps_markers_box', $attributes['post_id']);
    $paths = get_field('maps_paths_box', $attributes['post_id']);

    // Start the KML file
    $kml = '<?xml version="1.0" encoding="UTF-8"?>';
    $kml .= '<kml xmlns="http://www.opengis.net/kml/2.2">';
    $kml .= '<Document>';

    // Add markers to the KML file
    foreach($markers as $marker) {
        $kml .= '<Placemark>';
        $kml .= '<name>' . $marker['maps_marker_title'] . '</name>';
        $kml .= '<Point>';
        $kml .= '<coordinates>' . $marker['maps_marker_longitude'] . ',' . $marker['maps_marker_latitude'] . '</coordinates>';
        $kml .= '</Point>';
        $kml .= '</Placemark>';
    }

    // Add paths to the KML file
    foreach($paths as $path) {
        $kml .= '<Placemark>';
        $kml .= '<name>' . $path['maps_path_title'] . '</name>';
        $kml .= '<LineString>';
        $kml .= '<coordinates>';
        foreach($path['coordinates'] as $coordinate) {
            $kml .= $coordinate . ' ';
        }
        $kml .= '</coordinates>';
        $kml .= '</LineString>';
        $kml .= '</Placemark>';
    }

    // End the KML file
    $kml .= '</Document>';
    $kml .= '</kml>';

    // Return the KML file
    echo $kml;
    wp_die(); // this is required to terminate immediately and return a proper response
}

//...converting name to lat lon
function convert_name_to_lat_lon($query) {
    $location = urlencode($query);
    $url = "https://nominatim.openstreetmap.org/search?format=json&addressdetails=1&debug=0&email=info@balmers.com&q=$location";

    // Make the request to Nominatim
    $response = wp_remote_get($url, array(
        'headers' => array('User-Agent' => 'WordPress Map Plugin for my site (info@balmers.com)')
    ));
    if (is_wp_error($response)) {
        return 'Geocoding failed';
    }

    $body = wp_remote_retrieve_body($response);
    $data = json_decode($body, true);
    if (empty($data)) {
        return 0;
    }

    return $data[0];
}
//--

//REGISTER POINT OF INTERESTS
add_action('init', 'create_point_of_interests_taxonomy');
function create_point_of_interests_taxonomy() {
    $labels = array(
        'name' => _x('Points of Interest', 'taxonomy general name', 'textdomain'),
        'singular_name' => _x('Point of Interest', 'taxonomy singular name', 'textdomain'),
        'search_items' => __('Search Points of Interest', 'textdomain'),
        'all_items' => __('All Points of Interest', 'textdomain'),
        'parent_item' => __('Parent Point of Interest', 'textdomain'),
        'parent_item_colon' => __('Parent Point of Interest:', 'textdomain'),
        'edit_item' => __('Edit Point of Interest', 'textdomain'),
        'update_item' => __('Update Point of Interest', 'textdomain'),
        'add_new_item' => __('Add New Point of Interest', 'textdomain'),
        'new_item_name' => __('New Point of Interest Name', 'textdomain'),
        'menu_name' => __('Points of Interest', 'textdomain'),
    );

    $args = array(
        'hierarchical' => true, // set to false for non-hierarchical (like tags)
        'labels' => $labels,
        'show_ui' => true,
        'show_admin_column' => true,
        'query_var' => true,
        'rewrite' => array('slug' => 'point-of-interest'),
    );

    register_taxonomy('point_of_interest', ['post'], $args); // Replace ['post'] with your custom post type if different
}
//--

//CUSTOM NAME FOR ACTIVITY
function change_portfolio_post_type_labels($args, $post_type) {
    if ('portfolio' === $post_type) {
        $args['labels']['name'] = 'Activities';
        $args['labels']['singular_name'] = 'Activity';
        $args['labels']['add_new'] = 'Add New Activity';
        $args['labels']['add_new_item'] = 'Add New Activity';
        $args['labels']['edit_item'] = 'Edit Activity';
        $args['labels']['new_item'] = 'New Activity';
        $args['labels']['view_item'] = 'View Activity';
        $args['labels']['search_items'] = 'Search Activities';
        $args['labels']['not_found'] = 'No Activities found';
        $args['labels']['not_found_in_trash'] = 'No Activities found in Trash';
        $args['labels']['all_items'] = 'All Activities';
        $args['labels']['menu_name'] = 'Activities';
        $args['menu_icon'] = 'dashicons-location-alt';
        $args['rewrite'] = ['slug' => 'activity'];
    }
    return $args;
}
add_filter('register_post_type_args', 'change_portfolio_post_type_labels', 10, 2);
//--

//ADD CUSTOM POST TO POST TYPE OBJECT
//..add fields to html structure
add_action('wp_ajax_acf/fields/taxonomy/add_term', 'yuna_ajax_add_term');
function yuna_ajax_add_term() {

    //only for specific field
    if($_POST['field_key'] != 'field_6634b3a006d7b'){
        return;
    }

    // verify nonce
    if ( ! acf_verify_ajax() ) {
        die();
    }

    // vars
    $args = wp_parse_args(
        $_POST,
        array(
            'nonce'       => '',
            'field_key'   => '',
            'term_name'   => '',
            'term_parent' => '',
            'poi_latitude' => '',
            'poi_longitude' => '',
            'description' => '',
            'poi_type' => '',
            'poi_category' => '',
            'poi_btn_url' => '',      
            'poi_btn_title' => '',    
        )
    );

    // load field
    $field = acf_get_field( $args['field_key'] );
    if ( ! $field ) {
        die();
    }

    // vars
    $taxonomy_obj   = get_taxonomy( $field['taxonomy'] );
    $taxonomy_label = $taxonomy_obj->labels->singular_name;

    // validate cap
    // note: this situation should never occur due to condition of the add new button
    if ( ! current_user_can( $taxonomy_obj->cap->manage_terms ) ) {
        wp_send_json_error(
            array(
                'error' => sprintf( __( 'User unable to add new %s', 'acf' ), $taxonomy_label ),
            )
        );
    }

    // save?
    if ( $args['term_name'] ) {

        // exists
        if ( term_exists( $args['term_name'], $field['taxonomy'], $args['term_parent'] ) ) {
            wp_send_json_error(
                array(
                    'error' => sprintf( __( '%s already exists', 'acf' ), $taxonomy_label ),
                )
            );
        }

        // vars
        $extra = array();
        if ( $args['term_parent'] ) {
            $extra['parent'] = (int) $args['term_parent'];
        }

        // insert
        $data = wp_insert_term( $args['term_name'], $field['taxonomy'], $extra );

        // error
        if ( is_wp_error( $data ) ) {
            wp_send_json_error(
                array(
                    'error' => $data->get_error_message(),
                )
            );
        }

        // load term
        $term = get_term( $data['term_id'] );
        //update_term_meta( $term_id, $field['name'], $value );
        update_term_meta($data['term_id'], 'poi_latitude', $args['poi_latitude']);
        update_term_meta($data['term_id'], 'poi_longitude', $args['poi_longitude']);
        update_term_meta($data['term_id'], 'poi_type', $args['poi_type']);
        update_term_meta($data['term_id'], 'poi_category', $args['poi_category']);
        update_term_meta($data['term_id'], 'poi_image', $args['poi_image']);
        //update_term_meta($data['term_id'], 'poi_url_link[url]', $args['poi_btn_url']);
        //update_term_meta($data['term_id'], 'poi_url_link[title]', $args['poi_btn_title']);
        $poi_url_link = array(
            'url' => $args['poi_btn_url'],
            'title' => $args['poi_btn_title'],
            'target' => '_blank' // assuming you have a target field
        );
        update_term_meta($data['term_id'], 'poi_url_link', $poi_url_link);
        wp_update_term($data['term_id'], $field['taxonomy'], array('description' => $args['description']));

        // prepend ancenstors count to term name
        $prefix    = '';
        $ancestors = get_ancestors( $term->term_id, $term->taxonomy );
        if ( ! empty( $ancestors ) ) {
            $prefix = str_repeat( '- ', count( $ancestors ) );
        }

        // success
        wp_send_json_success(
            array(
                'message'     => sprintf( __( '%s added', 'acf' ), $taxonomy_label ),
                'term_id'     => $term->term_id,
                'term_name'   => $term->name,
                'poi_latitude'    => $args['poi_latitude'],
                'poi_longitude'    => $args['poi_longitude'],
                'poi_type'    => $args['poi_type'],
                'poi_category'    => $args['poi_category'],
                'poi_image'    => $args['poi_image'],
                'poi_url_link'    => $poi_url_link,
                'description'    => $args['description'],
                'term_label'  => $prefix . $term->name,
                'term_parent' => $term->parent,
            )
        );
    }

    ?>
<form method="post">
    <?php

    acf_render_field_wrap(
        array(
            'label' => __( 'Name', 'acf' ),
            'name'  => 'term_name',
            'type'  => 'text',
        )
    );

    acf_render_field_wrap(
        array(
            'label' => __( 'Description', 'acf' ),
            'name'  => 'description',
            'type'  => 'wysiwyg',
            'value' => 'Text, link and description of the point of interest',
            'instructions' => 'Limit the style and links to a bare minimum',
            'toolbar' => 'basic',
            'media_upload' => 0,
            'delay' => 0,
        )
    );

    acf_render_field_wrap(
        array(
            'label' => __( 'Latitude', 'acf' ),
            'name'  => 'poi_latitude',
            'type'  => 'text',
        )
    );

    acf_render_field_wrap(
        array(
            'label' => __( 'Longitude', 'acf' ),
            'name'  => 'poi_longitude',
            'type'  => 'text',
        )
    );

    acf_render_field_wrap(
        array(
            'label' => __( 'Type', 'acf' ),
            'name'  => 'poi_type',
            'type'  => 'select',
            'choices' => array(
                'food' => 'Restaurant',
                'night'      => 'Bar',
                'land'     => 'Landmark',
                'transport'    => 'Transportation',
                'hike'     => 'Hike Start/End Point',
                'shop'     => 'Grocery or Shopping',
                'public'   => 'Police, Hospital, Public Buildings',
                'other'    => 'Other',
            ),
        )
    );

    acf_render_field_wrap(
        array(
            'label' => __( 'Category', 'acf' ),
            'name'  => 'poi_category',
            'type'  => 'select',
            'choices' => array(
                'md-local-airport' => 'Airport',
                'md-beach-access' => 'Beach',
                'map-amusement-park' => 'Amusement Park',
                'map-aquarium' => 'Aquarium',
                'map-art-gallery' => 'Art Gallery',
                'map-atm' => 'ATM',
                'map-bakery' => 'Bakery',
                'map-bank' => 'Bank',
                'map-bar' => 'Bar',
                'map-baseball' => 'Baseball',
                'map-beauty-salon' => 'Beauty Salon',
                'map-bicycle-store' => 'Bicycle Store',
                'map-boat-ramp' => 'Boat Ramp',
                'map-boat-tour' => 'Boat Tour',
                'map-boating' => 'Boating',
                'map-book-store' => 'Book Store',
                'map-bowling-alley' => 'Bowling Alley',
                'md-directions-bus' => 'Bus Station',
                'md-local-cafe' => 'Cafe',
                'map-campground' => 'Campground',
                'map-canoe' => 'Canoe',
                'md-directions-car' => 'Car Rental',
                'map-car-repair' => 'Car Repair',
                'map-car-wash' => 'Car Wash',
                'map-casino' => 'Casino',
                'map-cemetery' => 'Cemetery',
                'map-chairlift' => 'Chairlift',
                'map-church' => 'Church',
                'map-city-hall' => 'City Hall',
                'md-location-city' => 'City / Village / Town',
                'map-climbing' => 'Climbing', 
                'md-local-mall' => 'Clothing Store',
                'map-compass' => 'Compass',
                'md-local-convenience-store' => 'Convenience Store',
                'map-cross-country-skiing' => 'Cross Country Skiing',
                'map-dentist' => 'Dentist',
                'map-diving' => 'Diving',
                'map-doctor' => 'Doctor',
                'map-electrician' => 'Electrician',
                'map-electronics-store' => 'Electronics Store',
                'map-embassy' => 'Embassy',
                'md-fastfood' => 'Fast Food',
                'map-finance' => 'Finance',
                'map-fire-station' => 'Fire Station',
                'map-fishing-pier' => 'Fishing Pier',
                'md-fitness-center' => 'Gym',
                'map-florist' => 'Florist',
                'map-food' => 'Food',
                'map-funeral-home' => 'Funeral Home',
                'map-furniture-store' => 'Furniture Store',
                'map-gas-station' => 'Gas Station', 
                'md-food-truck' => 'Food Truck',
                'md-forest' => 'Forest',
                'md-local-florist' => 'Flower Shop',
                'md-local-grocery-store' => 'Grocery Store',
                'md-hardware' => 'Hardware Store',
                'map-gym' => 'Gym',
                'map-hair-care' => 'Hair Care',
                'map-hang-gliding' => 'Hang Gliding',
                'map-health' => 'Health',
                'map-hindu-temple' => 'Hindu Temple',
                'md-hiking' => 'Hike',
                'map-hospital' => 'Hospital',
                'md-hotel' => 'Hotel',
                'md-night-shelter' => 'Hostel',
                'map-ice-fishing' => 'Ice Fishing',
                'map-ice-skating' => 'Ice Skating',
                'map-inline-skating' => 'Inline Skating',
                'map-insurance-agency' => 'Insurance Agency',
                'map-jet-skiing' => 'Jet Skiing',
                'md-local-jewelry' => 'Jewelry Store',
                'map-kayaking' => 'Kayaking',
                'map-laundry' => 'Laundry',
                'map-lawyer' => 'Lawyer',
                'md-landscape' => 'Landscape',
                'md-local-library' => 'Library',
                'map-liquor-store' => 'Liquor Store',
                'map-local-government' => 'Local Government',
                'map-locksmith' => 'Locksmith',
                'map-lodging' => 'Lodging',
                'map-map-pin' => 'Map Pin',
                'map-marina' => 'Marina',
                'md-mosque' => 'Mosque',
                'map-movie-rental' => 'Movie Rental',
                'map-movie-theater' => 'Movie Theater',
                'md-museum' => 'Museum',
                'map-natural-feature' => 'Natural Feature',
                'md-nightlife' => 'Night Club', 
                'md-park' => 'Park',
                'md-pets' => 'Pet Store',
                'md-local-pharmacy' => 'Pharmacy',
                'map-place-of-worship' => 'Place of Worship',
                'md-place' => 'Place',
                'map-playground' => 'Playground',
                'map-point-of-interest' => 'Point of Interest',
                'map-political' => 'Political',
                'md-local-police' => 'Police, Hospital, Public Buildings',
                'map-post-office' => 'Post Office',
                'map-rafting' => 'Rafting',
                'map-real-estate-agency' => 'Real Estate Agency',
                'md-restaurant' => 'Restaurant',
                'map-route' => 'Route',
                'map-route-pin' => 'Route Pin',
                'map-rv-park' => 'RV Park',
                'map-sailing' => 'Sailing',
                'md-river' => 'River/Lake/Water',
                'md-school' => 'School',
                'map-scuba-diving' => 'Scuba Diving',
                'md-sports-stadium' => 'Stadium',
                'map-skateboarding' => 'Skateboarding',
                'map-ski-jumping' => 'Ski Jumping',
                'map-skiing' => 'Skiing',
                'map-sledding' => 'Sledding',
                'map-snow' => 'Snow',
                'map-snow-shoeing' => 'Snow Shoeing',
                'map-snowboarding' => 'Snowboarding',
                'map-snowmobile' => 'Snowmobile',
                'map-spa' => 'Spa',
                'map-stadium' => 'Stadium',
                'map-storage' => 'Storage',
                'map-store' => 'Store',
                'md-streetview' => 'Street Food',
                'md-subway' => 'Subway Station',
                'map-surfing' => 'Surfing',
                'map-swimming' => 'Swimming',
                'md-synagogue' => 'Synagogue',
                'map-taxi-stand' => 'Taxi Stand',
                'map-tennis' => 'Tennis',
                'map-toilet' => 'Toilet',
                'md-temple' => 'Temple',
                'map-transit-station' => 'Transit Station',
                'map-travel-agency' => 'Travel Agency',
                'md-train' => 'Train Station',
                'map-university' => 'University',
                'map-waterskiing' => 'Waterskiing',
                'map-whale-watching' => 'Whale Watching',
                'map-wheelchair' => 'Wheelchair',
                'map-wind-surfing' => 'Wind Surfing',
                'md-wine-bar' => 'Wine Bar',
                'md-zoo' => 'Zoo'
            )
        )
    );

    acf_render_field_wrap(
        array(
            'label' => __( 'Image', 'acf' ),
            'name'  => 'poi_image',
            'type'  => 'image',
        )
    );

    acf_render_field_wrap(
        array(
            'label' => __( 'Button Info', 'acf' ),
            'name'  => 'poi_url_link',
            'type'  => 'link',
        )
    );

    ?>
<p class="acf-submit">
    <button class="acf-submit-button button button-primary" type="submit"><?php esc_html_e( 'Add', 'acf' ); ?></button>
</p>
</form><?php

// die
die;
}

//..custom script
add_action('admin_head', 'yuna_map_custom_script');
function yuna_map_custom_script() { 

    //if (!is_admin()) {
    //    return;
    //}

    // Get the current screen
    $current_screen = get_current_screen();

    // Check if the current screen is not a post edit screen
    if ($current_screen && $current_screen->base !== 'post' && $current_screen->action !== 'edit') {
        return;
    }

    ob_start();
    ?>
    <script type="text/javascript">
    (function ($, undefined) {
        var Field = acf.Field.extend({
            type: 'taxonomy',
            data: {
                ftype: 'select'
            },
            select2: false,
            wait: 'load',
            events: {
                'click .acf-taxonomy-field a[data-name="add"]': 'onClickAdd',
                'click input[type="radio"]': 'onClickRadio',
                removeField: 'onRemove',
            },
            $control: function () {
                return this.$('.acf-taxonomy-field');
            },
            $input: function () {
                return this.getRelatedPrototype().$input.apply(this, arguments);
            },
            getRelatedType: function () {
                // vars
                var fieldType = this.get('ftype');
        
                // normalize
                if (fieldType == 'multi_select') {
                fieldType = 'select';
                }
        
                // return
                return fieldType;
            },
            getRelatedPrototype: function () {
                return acf.getFieldType(this.getRelatedType()).prototype;
            },
            getValue: function () {
                return this.getRelatedPrototype().getValue.apply(this, arguments);
            },
            setValue: function () {
                return this.getRelatedPrototype().setValue.apply(this, arguments);
            },
            initialize: function () {
                this.getRelatedPrototype().initialize.apply(this, arguments);
            },
            onRemove: function () {
                var proto = this.getRelatedPrototype();
                if (proto.onRemove) {
                proto.onRemove.apply(this, arguments);
                }
            },
            onClickAdd: function (e, $el) {
                // vars
                var field = this;
                var popup = false;
                var $form = false;
                var $name = false;
                var $parent = false;
                var $button = false;
                var $message = false;
                var notice = false;
        
                // step 1.
                var step1 = function () {
                    // popup
                    popup = acf.newPopup({
                        title: $el.attr('title'),
                        loading: true,
                        width: '80vw'
                    });
        
                    // ajax
                    var ajaxData = {
                        action: 'acf/fields/taxonomy/add_term',
                        field_key: field.get('key')
                    };
        
                    // get HTML
                    $.ajax({
                        url: acf.get('ajaxurl'),
                        data: acf.prepareForAjax(ajaxData),
                        type: 'post',
                        dataType: 'html',
                        success: step2
                    });
                };
      
                // step 2.
                var step2 = function (html) {
                    // update popup
                    popup.loading(false);
                    popup.content(html);
                    // initializeEditor if textarea
                    if (popup.$('.acf-editor-wrap').hasClass('wp-editor-wrap')) {
                        // vars
                        var $wrap = popup.$('.acf-editor-wrap');
                        var $textarea = popup.$('textarea');
                        var args = {
                            tinymce: true,
                            quicktags: true,
                            toolbar: popup.get('toolbar'),
                            mode: popup.$('.acf-editor-wrap').hasClass('tmce-active') ? 'visual' : 'text',
                            field: $textarea
                        };

                        // generate new id
                        var oldId = $textarea.attr('id');
                        var newId = acf.uniqueId('acf-editor-');

                        // Backup textarea data.
                        var inputData = $textarea.data();
                        var inputVal = $textarea.val();

                        // rename
                        acf.rename({
                            target: $wrap,
                            search: oldId,
                            replace: newId,
                            destructive: true
                        });

                        // update id
                        $textarea.attr('id', newId);

                        // apply data to new textarea (acf.rename creates a new textarea element due to destructive mode)
                        // fixes bug where conditional logic "disabled" is lost during "screen_check"
                        $textarea.data(inputData).val(inputVal);

                        // initialize
                        acf.tinymce.initialize(newId, args);

                    }
                    attachImgHandler();
                    linkHandler();

                    // vars
                    $form = popup.$('form');
                    $name = popup.$('input[name="term_name"]');
                    $latitude = popup.$('input[name="poi_latitude"]');
                    $longitude = popup.$('input[name="poi_longitude"]');
                    $poi_type = popup.$('select[name="poi_type"]');
                    $poi_category = popup.$('select[name="poi_category"]');
                    $poi_img = popup.$('input[name="poi_image"]');
                    $poi_btn_url = popup.$('input[name="poi_url_link[url]"]');
                    $poi_btn_title = popup.$('input[name="poi_url_link[title]"]');
                    $description = popup.$('textarea[name="description"]');
                    $parent = popup.$('select[name="term_parent"]');
                    $button = popup.$('.acf-submit-button');
            
                    // focus
                    $name.trigger('focus');
            
                    // submit form
                    popup.on('submit', 'form', step3);
                };
      
                // step 3.
                var step3 = function (e, $el) {
                // prevent
                e.preventDefault();
                e.stopImmediatePropagation();
        
                // basic validation
                if ($name.val() === '') {
                    $name.trigger('focus');
                    return false;
                }
        
                // disable
                acf.startButtonLoading($button);
        
                // ajax
                var ajaxData = {
                    action: 'acf/fields/taxonomy/add_term',
                    field_key: field.get('key'),
                    term_name: $name.val(),
                    description: $description.val(),
                    poi_type: $poi_type.val(),
                    poi_category: $poi_category.val(),
                    poi_latitude: $latitude.val(),
                    poi_longitude: $longitude.val(),
                    poi_image: $poi_img.val(),
                    poi_btn_url: $poi_btn_url.val(),
                    poi_btn_title: $poi_btn_title.val(),
                    term_parent: $parent.length ? $parent.val() : 0
                };
                $.ajax({
                    url: acf.get('ajaxurl'),
                    data: acf.prepareForAjax(ajaxData),
                    type: 'post',
                    dataType: 'json',
                    success: step4
                });
                };
      
                // step 4.
                var step4 = function (json) {
                // enable
                acf.stopButtonLoading($button);
        
                // remove prev notice
                if (notice) {
                    notice.remove();
                }
        
                // success
                if (acf.isAjaxSuccess(json)) {
                    // clear name
                    $name.val('');
                    $latitude.val('');
                    $longitude.val('');
                    $poi_type.val('');
                    $poi_category.val('');
                    $tinymceID = $description.attr("id");
                    $tinymceInstance = tinyMCE.editors[$tinymceID];
                    if($tinymceInstance) {
                        $tinymceInstance.setContent('');
                    }
                    var controlClear = $('#acf-popup .acf-image-uploader');
                    var inputCtrlClear = controlClear.find('input[name="poi_image"]');
                    inputCtrlClear.val('');
                    controlClear.removeClass('has-value');

                    var controlLinkClear = $('#acf-popup .acf-field-link');
                    controlLinkClear.find('.link-title').html('');
                    controlLinkClear.find('.link-url').attr('href', '').html('');
                    controlLinkClear.find('.input-url').val('');
                    controlLinkClear.find('.input-title').val('');
                    controlLinkClear.find('.acf-link').removeClass('-value');
        
                    // update term lists
                    step5(json.data);
        
                    // notice
                    notice = acf.newNotice({
                    type: 'success',
                    text: acf.getAjaxMessage(json),
                    target: $form,
                    timeout: 2000,
                    dismiss: false
                    });
                } else {
                    // notice
                    notice = acf.newNotice({
                    type: 'error',
                    text: acf.getAjaxError(json),
                    target: $form,
                    timeout: 2000,
                    dismiss: false
                    });
                }
        
                // focus
                $name.trigger('focus');
                };
      
                // step 5.
                var step5 = function (term) {
                // update parent dropdown
                var $option = $('<option value="' + term.term_id + '">' + term.term_label + '</option>');
                if (term.term_parent) {
                    $parent.children('option[value="' + term.term_parent + '"]').after($option);
                } else {
                    $parent.append($option);
                }
        
                // add this new term to all taxonomy field
                var fields = acf.getFields({
                    type: 'taxonomy'
                });
                fields.map(function (otherField) {
                    if (otherField.get('taxonomy') == field.get('taxonomy')) {
                    otherField.appendTerm(term);
                    }
                });
        
                // select
                field.selectTerm(term.term_id);
                };
      
                // run
                step1();

                var linkHandler = function(){
                    var control = $('#acf-popup .acf-link');

                    function renderLink(val) {
                        val = validateLink(val);
                        control.find('.link-title').html(val.title);
                        control.find('.link-url').attr('href', val.url).html(val.url);
                        console.log('val.url:'+val.url+' title:'+val.title);
                        if (val.url) {
                            control.find('.input-title').val(val.title);
                            control.find('.input-url').val(val.url);
                            control.addClass('-value');
                        } else {
                            control.find('.input-title').val('');
                            control.find('.input-url').val('');
                            control.removeClass('-value');
                        }
                    }

                    function validateLink(val) {
                        if (!val) return { title: '', url: '', target: '' };
                        return acf.parseArgs(val, {
                            title: '',
                            url: '',
                            target: ''
                        });
                    }

                    $(document).on('click', '.acf-field-link a[data-name="add"], .acf-field-link a[data-name="edit"]', function(event) {
                        acf.wpLink.open(control.find('.link-node'));
                    });

                    $(document).on('click', '.acf-field-link a[data-name="remove"]', function(event) {
                        renderLink(false);
                    });

                    $(document).on('change', '.link-node', function(e) {
                        var val = getValue();
                        renderLink(val);
                    });

                    function getValue() {
                        var $node = control.find('.link-node');
                        if (!$node.attr('href')) return false;
                        return {
                            title: $node.html(),
                            url: $node.attr('href'),
                            target: $node.attr('target')
                        };
                    }
                };


                var attachImgHandler = function(){ 
                    var control = $('#acf-popup .acf-image-uploader');
                    var inputCtrl = control.find('input[name="poi_image"]');
                    //RENDER FUNC
                    function render(attachment) {
                        attachment = validateAttachment(attachment);

                        // Update DOM.
                        control.find('img').attr({
                            src: attachment.url,
                            alt: attachment.alt
                        });
                        if (attachment.id) {
                            inputCtrl.val(attachment.id);
                            control.addClass('has-value');
                        } else {
                            inputCtrl.val('');
                            control.removeClass('has-value');
                        }
                    }

                    //VALIDATE FUNC
                    function validateAttachment(attachment) {
                        // Use WP attachment attributes when available.
                        if (attachment && attachment.attributes) {
                            attachment = attachment.attributes;
                        }

                        // Apply defaults.
                        attachment = acf.parseArgs(attachment, {
                            id: 0,
                            url: '',
                            alt: '',
                            title: '',
                            caption: '',
                            description: '',
                            width: 0,
                            height: 0
                        });

                        // Override with "preview size".
                        var size = acf.isget(attachment, 'sizes', $(this).get('preview_size'));
                        if (size) {
                            attachment.url = size.url;
                            attachment.width = size.width;
                            attachment.height = size.height;
                        }

                        // Return.
                        return attachment;
                    }

                    //CLICK ADD IMAGE
                    $(document).on('click', '.acf-field-image a[data-name="add"]', function(event) {
                        console.log('Add button clicked.');
                        // vars
                        var parent = $(this).parent();
                        var multiple = parent && parent.get('type') === 'repeater';

                        // new frame
                        var frame = acf.newMediaPopup({
                            mode: 'select',
                            type: 'image',
                            title: acf.__('Select Image'),
                            field: $(this).get('key'),
                            multiple: multiple,
                            library: $(this).get('library'),
                            allowedTypes: $(this).get('mime_types'),
                            select: $.proxy(function (attachment, i) {
                            if (i > 0) {
                                append(attachment, parent);
                            } else {
                                render(attachment);
                            }
                            }, $(this))
                        });
                    });

                    //CLICK EDIT
                    $(document).on('click', '.acf-field-image a[data-name="edit"]', function(event) {
                        console.log('Edit button clicked.');
                        var val = inputCtrl.val();
                        // bail early if no val
                        if (!val) return;

                        // popup
                        var frame = acf.newMediaPopup({
                            mode: 'edit',
                            title: acf.__('Edit Image'),
                            button: acf.__('Update Image'),
                            attachment: val,
                            field: $(this).get('key'),
                            select: $.proxy(function (attachment, i) {
                                render(attachment);
                            }, $(this))
                        });

                    });

                    //CLICK REMOVE
                    $(document).on('click', '.acf-field-image a[data-name="remove"]', function(event) {
                        console.log('Remove button clicked.');
                        // remove
                        render(false);
                    });

                    //ON CHANGE
                    $(document).on('change', '.acf-field-image input[type="file"]', function(e) {
                        var $hiddenInput = $(this).find('input[type="hidden"]:first');
                        if (e.val()) {
                            $hiddenInput.val('');
                        }
                        acf.getFileInputData(e, function (data) {
                            $hiddenInput.val($.param(data));
                        });
                    });
                };
            },
            appendTerm: function (term) {
                if (this.getRelatedType() == 'select') {
                this.appendTermSelect(term);
                } else {
                this.appendTermCheckbox(term);
                }
            },
            appendTermSelect: function (term) {
                this.select2.addOption({
                id: term.term_id,
                text: term.term_label
                });
            },
            appendTermCheckbox: function (term) {
                // vars
                var name = this.$('[name]:first').attr('name');
                var $ul = this.$('ul:first');
        
                // allow multiple selection
                if (this.getRelatedType() == 'checkbox') {
                name += '[]';
                }
        
                // create new li
                var $li = $(['<li data-id="' + term.term_id + '">', '<label>', '<input type="' + this.get('ftype') + '" value="' + term.term_id + '" name="' + name + '" /> ', '<span>' + term.term_name + '</span>', '</label>', '</li>'].join(''));
        
                // find parent
                if (term.term_parent) {
                // vars
                var $parent = $ul.find('li[data-id="' + term.term_parent + '"]');
        
                // update vars
                $ul = $parent.children('ul');
        
                // create ul
                if (!$ul.exists()) {
                    $ul = $('<ul class="children acf-bl"></ul>');
                    $parent.append($ul);
                }
                }
        
                // append
                $ul.append($li);
            },
            selectTerm: function (id) {
                if (this.getRelatedType() == 'select') {
                this.select2.selectOption(id);
                } else {
                var $input = this.$('input[value="' + id + '"]');
                $input.prop('checked', true).trigger('change');
                }
            },
            onClickRadio: function (e, $el) {
                // vars
                var $label = $el.parent('label');
                var selected = $label.hasClass('selected');
        
                // remove previous selected
                this.$('.selected').removeClass('selected');
        
                // add active class
                $label.addClass('selected');
        
                // allow null
                if (this.get('allow_null') && selected) {
                $label.removeClass('selected');
                $el.prop('checked', false).trigger('change');
                }
            }
        });
        acf.registerFieldType(Field);

      })(jQuery);

      </script>
        <style>
            #acf-popup .acf-popup-box {overflow-y: scroll;height: 80vh;}
            #acf-popup {z-index: 9999;}
            .acf-field[data-name="description"] p.description {color: red !important;}
        </style>
    <?php
    $exportjs = ob_get_clean();
    echo $exportjs;
}
//--

//PWA BALMERS - Add to Home Screen
function pwa_scripts() {
    $plugin_url = plugin_dir_url(__FILE__);
    wp_register_script('sw-register', $plugin_url . 'js/sw.js', null, null, true);
    wp_localize_script('sw-register', 'websiteinfo', array('url' => site_url('/')));
    wp_enqueue_script('sw-register');


    wp_enqueue_script('bowser', $plugin_url . 'js/es5.min.js', null, null, true);

    wp_enqueue_style('innsight-style', $plugin_url . 'css/yuna-innsight.css');
    
    // Add inline style with the plugin URL
    $custom_css = "
        :root {
            --innSight-icon: url('{$plugin_url}img/icon-512.png');
            --innSight-gmaps: url('{$plugin_url}img/google-maps-balmers.png');
            --innSight-mapsme: url('{$plugin_url}img/maps-me-balmers.png');
            --innSight-apple: url('{$plugin_url}img/apple-maps-balmers.png');
        }
    ";
    wp_add_inline_style('innsight-style', $custom_css);
}
add_action('wp_enqueue_scripts', 'pwa_scripts', 10);
function add_manifest_link() {
    echo '<link rel="manifest" href="' . plugin_dir_url(__FILE__) . 'manifest.json">';
    echo '<meta name="theme-color" content="#FFFFFF">';
    echo '<link rel="apple-touch-icon" href="'.plugin_dir_url(__FILE__).'img/hostel-icon-ios.png">';

    //iOS fixes
    echo '<link rel="apple-touch-icon" sizes="152x152" href="'.plugin_dir_url(__FILE__).'img/hostel-icon-ipad.png">';
    echo '<link rel="apple-touch-icon" sizes="180x180" href="'.plugin_dir_url(__FILE__).'img/hostel-icon-iphone-retina.png">';
    echo '<link rel="apple-touch-icon" sizes="167x167" href="'.plugin_dir_url(__FILE__).'img/hostel-icon-ipad-retina.png">';
    
    //iOS Splash screen (loading)
    echo '<meta name="mobile-web-app-capable" content="yes">';
    echo '<link href="'.plugin_dir_url(__FILE__).'img/apple_splash_2048.png" sizes="2048x2732" rel="apple-touch-startup-image" />';
    echo '<link href="'.plugin_dir_url(__FILE__).'img/apple_splash_1668.png" sizes="1668x2224" rel="apple-touch-startup-image" />';
    echo '<link href="'.plugin_dir_url(__FILE__).'img/apple_splash_1536.png" sizes="1536x2048" rel="apple-touch-startup-image" />';
    echo '<link href="'.plugin_dir_url(__FILE__).'img/apple_splash_1125.png" sizes="1125x2436" rel="apple-touch-startup-image" />';
    echo '<link href="'.plugin_dir_url(__FILE__).'img/apple_splash_1242.png" sizes="1242x2208" rel="apple-touch-startup-image" />';
    echo '<link href="'.plugin_dir_url(__FILE__).'img/apple_splash_750.png" sizes="750x1334" rel="apple-touch-startup-image" />';
    echo '<link href="'.plugin_dir_url(__FILE__).'img/apple_splash_640.png" sizes="640x1136" rel="apple-touch-startup-image" />';
}
add_action('wp_head', 'add_manifest_link');
function register_map_page_template( $templates ) {
    // Adds your template to the page dropdown for v4.7+
    $templates[plugin_dir_path(__FILE__) . 'page-map.php'] = 'Map Page Fullscreen';
    return $templates;
}
add_filter('theme_page_templates', 'register_map_page_template');

function load_plugin_template( $template ) {
    // Check if the selected page template matches the one in the plugin
    if ( get_page_template_slug() === plugin_dir_path(__FILE__) . 'page-map.php' ) {
        // If it matches, return the plugin template path
        return plugin_dir_path(__FILE__) . 'page-map.php';
    }
    // Otherwise, return the default template
    return $template;
}
add_filter('page_template', 'load_plugin_template');

//iOS fix
function is_ios() {
    $user_agent = $_SERVER['HTTP_USER_AGENT'];
    return stripos($user_agent, 'iPhone') !== false || stripos($user_agent, 'iPad') !== false || stripos($user_agent, 'iPod') !== false;
}

function display_ios_install_prompt() {
    
    if (is_ios()) {
        ?>
        <div id="pop_ios" data-browser="safari">
            <div class="container">
                <div class="close_btn" onclick="document.getElementById('pop_ios').style.display='none';"></div>
                <img src="<?php echo plugin_dir_url(__FILE__); ?>img/hostel-icon-ios.png" alt="App Icon" class="app-icon main">
                <h2>Install the innSight app to continue</h2>
                <div class="instruction">
                    <div class="instruction-item">
                        <div class="step-number">1</div>
                        <div>
                            Tap the     <svg xmlns="http://www.w3.org/2000/svg" height="24" viewBox="0 0 24 24" width="24" fill="#4aa0ee"><path d="M0 0h24v24H0V0z" fill="none"></path><path d="M16 5l-1.42 1.42-1.59-1.59V16h-1.98V4.83L9.42 6.42 8 5l4-4 4 4zm4 5v11c0 1.1-.9 2-2 2H6c-1.11 0-2-.9-2-2V10c0-1.11.89-2 2-2h3v2H6v11h12V10h-3V8h3c1.1 0 2 .89 2 2z"></path></svg> button below.
                        </div>
                    </div>
                    <div class="instruction-item">
                        <div class="step-number">2</div>
                        <div>
                            Select <b class="home_screen">Add to Home Screen</b>  from the menu that pops up. 
                            <div class="note">You may need to scroll down to find this menu item.</div>
                        </div>
                    </div>
                    <div class="instruction-item">
                        <div class="step-number">3</div>
                        <div>
                            <a href="webapp://www.balmers.com/balmers-interactive-map-of-interlaken-switzerland/">Open the <img class="small app-icon" src="<?php echo plugin_dir_url(__FILE__); ?>img/hostel-icon-ios.png" alt="Aardvark App Icon"> app. </a>
                        </div>
                    </div>
                </div>
                <div class="chrome_ios"><h2>Oups!</h2> Your browser does not allow to download our map. Please use <a id="open-in-safari" href="https://www.balmers.com/balmers-interactive-map-of-interlaken-switzerland/">open your Safari browser</a> and follow instructions</div>
            </div>
            <div class="backdrop_bg"></div>
        </div>
        <style>
            div#pop_ios{display:none;position:fixed;z-index:99;top:0;left:0;width:100%;height:100%;margin:0;flex-direction:column;justify-content:center;align-items:center}
            .app-icon{width:50px;height:50px}
            .instruction{margin-top:20px;text-align:left}
            .instruction-item{display:flex;align-items:flex-start;margin-bottom:15px}
            .instruction-item img{width:24px;height:24px;margin-right:10px}
            .instruction-item .step-number{font-weight:700;margin-right:10px;display:flex;background:#aaa;color:#fff;min-width:40px;min-height:40px;justify-content:center;align-items:center;border-radius:40px}
            .note{font-size:.9em;color:#000;font-weight:600;line-height:1.3em;margin:10px 0 0}
            div#pop_ios .backdrop_bg:after{top:0;left:0;right:0;bottom:0;width:100%;height:100%;background:#333333aa;display:flex;justify-content:center;align-items:center;content:'';z-index:-1;backdrop-filter:blur(6px);position:absolute}
            div#pop_ios .container{background:#f5f5f5;padding:50px 20px 20px;box-shadow:0 4px 8px rgba(0,0,0,.1);border-radius:10px;font-family:Arial,sans-serif}
            #pop_ios .close_btn{position:fixed;top:10px;right:10px}
            #pop_ios .close_btn:before{content:'close';background:#ffffff33;color:#fff;display:flex;justify-content:center;align-items:center;padding:0 20px;text-transform:uppercase;font-size:10px;border-radius:5px;letter-spacing:1px}
            #pop_ios .instruction-item img.small.app-icon{position:relative;top:7px;left:0;transform:none;border-radius:5px;margin:0 5px;width:30px;height:30px}
            #pop_ios .instruction-item img.share_icon{margin:0 5px;background:#fff;color:red}
            div#pop_ios:after{content:'↓';position:absolute;bottom:20px;left:0;right:0;color:#84c4ff;font-size:80px;line-height:1em;font-weight:900;animation:upDown 1s infinite;font-family:Arial,sans-serif;text-align:center}
            #pop_ios b.home_screen:after{content:'+';border:1px solid;border-radius:5px;padding:0 5px;margin:0 0 0 5px;font-size:1.4em;position:relative;top:2px}
            #pop_ios b.home_screen{display:inline-block;background:#fff;padding:0 15px 2px 12px;font-size:.7em;box-shadow:1px 1px 3px #33333333;border-radius:5px;margin:0 5px;font-weight:500;top:-2px;position:relative}
            img.app-icon.main{width:100px;height:100px;position:absolute;top:-70px;border-radius:10px;box-shadow:1px 1px 5px #33333333;left:50%;transform:translate(-45%,0)}
            div#pop_ios a{color:#4aa0ee}
            div#pop_ios[data-browser=chrome]:after{display:none;}
            div#pop_ios[data-browser=chrome] .instruction{display:none}
            div#pop_ios[data-browser=chrome] .chrome_ios{display:block}
            div#pop_ios .chrome_ios{display:none;background:#ff000026;padding:30px 20px;text-align:center;border:4px dashed red;width:97%;margin:0 auto}

            @keyframes upDown{0%{transform:translateY(0)}50%{transform:translateY(-20px)}100%{transform:translateY(0)}}
        </style>
        <?php
    }
}
//add_action('wp_footer', 'display_ios_install_prompt');
//--


function add_footer_manifest_link() {
    ob_start(); ?>
    <!-- PWA BALMERS MAP -->
    <div id="add_home_screen" style="display:none;">
        <button id="install-button" style="display: none;">Add Staff Recomendations Map to Home Screen</button>
        <button id="btnClose">Close</button>
    </div>
    <script>
    let deferredPrompt;

    //PROMPT INSTALL SCRIPT
    window.addEventListener('beforeinstallprompt', (e) => {
        e.preventDefault();
        deferredPrompt = e;
        console.log('in here >> beforeinstallprompt');
        // Check if we've already displayed the prompt to the user
        if (!localStorage.getItem('userDismissedPrompt')) {
            document.getElementById('install-button').style.display = 'inline-flex';
            document.getElementById('add_home_screen').style.display = 'flex';
            document.querySelectorAll('.bookNow_bar').forEach(element => {
                element.classList.add('mod');
            });
        }
    });

    //DEFINE BROWSER
    document.addEventListener("DOMContentLoaded", function() {
        var parser = bowser.getParser(window.navigator.userAgent);
        var browserName = parser.getBrowserName().toLowerCase();
        console.log('browserName: '+browserName);
        var popIosElement = document.getElementById('pop_ios');
        if (popIosElement) {
            popIosElement.setAttribute('data-browser', browserName);
        }
    });


    //OPEN IN SAFARI MODE
    var safariLink = document.getElementById('open-in-safari');
    if (safariLink) {
        safariLink.addEventListener('click', function(event) {
            event.preventDefault();
            var url = this.href;

            // Use a trick to force the URL to open in Safari
            window.location.href = 'x-web-search://?' + encodeURIComponent(url);
        });
    }

    //OPEN APP TRIGGER + iOS install fix
    function onAppTriggerClick() {
        const isIos = () => {
            const userAgent = window.navigator.userAgent.toLowerCase();
            return /iphone|ipad|ipod/.test( userAgent );
        }
        
        // Checks if should display install popup notification:
        if (isIos()) {
            console.log('show install message');
            document.getElementById('pop_ios').style.display = 'flex';
        }else {
            console.log('app trigger clicked');
            if (deferredPrompt) {
                deferredPrompt.prompt();
                deferredPrompt.userChoice.then((choiceResult) => {
                    if (choiceResult.outcome === 'accepted') {
                        console.log('User accepted the A2HS prompt');
                        localStorage.setItem('userAddedToHomeScreen', 'true'); // Set a flag in local storage
                    } else {
                        console.log('User dismissed the A2HS prompt');
                        localStorage.setItem('userDismissedPrompt', 'true'); // Set a flag in local storage
                    }
                    deferredPrompt = null;
                    var btnAddElement = document.getElementById('btnAdd');
                    if (btnAddElement) {btnAddElement.style.display = 'none';}

                    var addHomeElement = document.getElementById('add_home_screen');
                    if(addHomeElement){ addHomeElement.style.display = 'none'; }
                    
                });
            }else{
                console.log('No deferredPrompt');
            }
        }
    }

    // Attach event listeners to all elements with the class .app_trigger
    document.getElementById('install-button').addEventListener('click', onAppTriggerClick);
    document.querySelectorAll('.app_trigger').forEach(element => {
        if (localStorage.getItem('userAddedToHomeScreen')) {
            element.textContent = element.getAttribute('data-altname');
            element.setAttribute('href', 'https://www.balmers.com/balmers-interactive-map-of-interlaken-switzerland/?utm_source=explore&utm_medium=button&utm_campaign=open_app');
            element.setAttribute('target', '_blank');
        } else {
            element.addEventListener('click', (e) => {
                e.preventDefault();
                onAppTriggerClick();
            });
        }
    });

    document.getElementById('btnClose').addEventListener('click', () => {
        document.getElementById('add_home_screen').style.display = 'none';
        localStorage.setItem('userDismissedPrompt', 'true'); // Set a flag in local storage
        document.querySelectorAll('.bookNow_bar').forEach(element => {
                element.classList.remove('mod');
            });
    });

    if ('serviceWorker' in navigator) {
        window.addEventListener('load', function() {
            navigator.serviceWorker.register('<?php echo plugin_dir_url(__FILE__); ?>js/sw.js')
            .then(function(registration) {
                console.log('ServiceWorker registration successful with scope: ', registration.scope);
            })
            .catch(function(err) {
                console.log('ServiceWorker registration failed: ', err);
            });
        });
    }

    </script>
    <!--END OF PWA-->
<?php
    echo ob_get_clean();

    display_ios_install_prompt();
}
add_action('wp_footer', 'add_footer_manifest_link');

//LANGUAGE FUNCTIONS
//..text
function translated_by_yuna($text) {
    global $my_transposh_plugin;
    $currentlang = transposh_get_current_language();
    //$translation = $my_transposh_plugin->database->fetch_translation($text, $currentlang)[1];
    $translation_result = $my_transposh_plugin->database->fetch_translation($text, $currentlang);
    $translation = (is_array($translation_result) && isset($translation_result[1])) ? $translation_result[1] : $text;
    if($translation == '') {
        return $text;
    }else{
        return $translation;
    }
}

//..url
function get_lang_url($url) {
    global $my_transposh_plugin;
    $currentlang = transposh_get_current_language();
    
    // Do not modify the URL for English
    if (strtolower($currentlang) === 'en') {
        return $url;
    }

    // Check if the URL already has parameters
    if (strpos($url, '?') !== false) {
        return $url . '&lang=' . $currentlang;
    } else {
        return $url . '?lang=' . $currentlang;
    }
}
//--

//POI Taxonomy URL fix
// Add the custom field to the taxonomy edit form with a select box
function add_main_more_info_field($term) {
    // Get current value if it exists
    $main_more_info_url = get_term_meta($term->term_id, 'main_more_info_url', true);

    // Fetch all posts associated with this taxonomy term
    $posts = get_posts(array(
        'post_type' => 'any', // You can specify post type if needed
        'tax_query' => array(
            array(
                'taxonomy' => 'point_of_interest',
                'field'    => 'term_id',
                'terms'    => $term->term_id,
            ),
        ),
        'numberposts' => -1 // Get all posts
    ));

    ?>
    <tr class="form-field">
        <th scope="row" valign="top">
            <label for="main_more_info_url"><?php _e('Main More Info Button URL'); ?></label>
        </th>
        <td>
            <select name="main_more_info_url" id="main_more_info_url">
                <?php
                if (!empty($posts)) {
                    foreach ($posts as $index => $post) {
                        $post_url = get_permalink($post->ID);
                        $selected = ($post_url == $main_more_info_url || ($index === 0 && empty($main_more_info_url))) ? 'selected="selected"' : '';
                        echo '<option value="' . esc_url($post_url) . '" ' . $selected . '>' . esc_html($post->post_title) . '</option>';
                    }
                } else {
                    echo '<option value="">' . __('No posts found for this taxonomy') . '</option>';
                }
                ?>
            </select>
            <p class="description"><?php _e('Select the main URL for this point of interest.'); ?></p>
        </td>
    </tr>
    <?php
}
add_action('point_of_interest_edit_form_fields', 'add_main_more_info_field');

// Save the selected post URL when the taxonomy term is saved
function save_main_more_info_field($term_id) {
    if (isset($_POST['main_more_info_url'])) {
        update_term_meta($term_id, 'main_more_info_url', sanitize_text_field($_POST['main_more_info_url']));
    }
}
add_action('edited_point_of_interest', 'save_main_more_info_field');
//--

?>
